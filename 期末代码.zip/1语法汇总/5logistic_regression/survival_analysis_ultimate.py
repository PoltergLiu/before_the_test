# -*- coding: utf-8 -*-
"""
生物医学统计 - 生存分析终极即插即用脚本 (Kaplan-Meier & Cox Regression)
功能：数据读取、自动哑变量处理、KM曲线、Log-rank检验、Cox回归、PH假设检验、森林图
作者：AI 助手 (针对期末考试优化)
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from lifelines import KaplanMeierFitter, CoxPHFitter, logrank_test
from lifelines.statistics import proportional_hazard_test
import os

# 设置中文显示
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False

class SurvivalAnalysisTool:
    def __init__(self, file_path, time_col, event_col):
        """
        初始化工具类
        :param file_path: 数据文件路径 (.xlsx 或 .csv)
        :param time_col: 时间列名
        :param event_col: 事件列名 (1=事件发生, 0=删失)
        """
        self.file_path = file_path
        self.time_col = time_col
        self.event_col = event_col
        self.df = self._load_data()
        self.cph = None
        
    def _load_data(self):
        """自动读取数据并简单清洗"""
        ext = os.path.splitext(self.file_path)[-1].lower()
        if ext == '.xlsx':
            df = pd.read_excel(self.file_path)
        else:
            df = pd.read_csv(self.file_path)
        
        # 删除时间或事件为空的行
        df = df.dropna(subset=[self.time_col, self.event_col])
        print(f"成功读取数据，共 {len(df)} 行。")
        return df

    def run_km_analysis(self, group_col=None):
        """
        绘制KM曲线并进行Log-rank检验
        :param group_col: 分组列名。如果不传，则绘制全人群曲线。
        """
        kmf = KaplanMeierFitter()
        plt.figure(figsize=(10, 6))
        
        if group_col and group_col in self.df.columns:
            groups = self.df[group_col].unique()
            for g in groups:
                mask = (self.df[group_col] == g)
                kmf.fit(self.df[self.time_col][mask], self.df[self.event_col][mask], label=f'{group_col}={g}')
                kmf.plot_survival_function()
            
            # Log-rank 检验 (仅支持两组或多组比较)
            if len(groups) >= 2:
                # 这里简单处理：如果是多组，默认进行两两比较或整体比较
                # 考试中通常是两组
                print(f"\n--- Log-rank Test for {group_col} ---")
                # 简单实现：这里展示第一组和第二组的比较
                g1, g2 = groups[0], groups[1]
                idx1 = (self.df[group_col] == g1)
                idx2 = (self.df[group_col] == g2)
                results = logrank_test(self.df[self.time_col][idx1], self.df[self.time_col][idx2],
                                       self.df[self.event_col][idx1], self.df[self.event_col][idx2])
                print(f"Comparison between {g1} and {g2}: p-value = {results.p_value:.4f}")
        else:
            kmf.fit(self.df[self.time_col], self.df[self.event_col], label='Full Population')
            kmf.plot_survival_function()
            
        plt.title(f'Kaplan-Meier Survival Curve (Group: {group_col if group_col else "None"})')
        plt.xlabel('Time')
        plt.ylabel('Survival Probability')
        plt.grid(True, linestyle='--', alpha=0.7)
        plt.show()

    def run_cox_regression(self, covariates, auto_dummy=True):
        """
        执行多因素Cox回归
        :param covariates: 协变量列表
        :param auto_dummy: 是否自动对非数值变量进行哑变量编码
        """
        analysis_cols = [self.time_col, self.event_col] + covariates
        data_subset = self.df[analysis_cols].copy()
        
        if auto_dummy:
            # 识别非数值列或分类列
            cat_cols = data_subset[covariates].select_dtypes(include=['object', 'category']).columns.tolist()
            # 也可以根据唯一值数量判断，例如唯一值 < 5 且不是 float
            for col in covariates:
                if col not in cat_cols and data_subset[col].nunique() < 6 and data_subset[col].dtype != float:
                    cat_cols.append(col)
            
            if cat_cols:
                print(f"正在对以下列进行哑变量编码: {cat_cols}")
                data_subset = pd.get_dummies(data_subset, columns=cat_cols, drop_first=True)
        
        # 处理缺失值
        if data_subset.isnull().values.any():
            print("警告：检测到缺失值，已自动删除包含缺失值的行。")
            data_subset = data_subset.dropna()

        self.cph = CoxPHFitter()
        self.cph.fit(data_subset, duration_col=self.time_col, event_col=self.event_col)
        
        print("\n--- Cox Proportional Hazards Regression Results ---")
        print(self.cph.summary[['exp(coef)', 'exp(coef) lower 95%', 'exp(coef) upper 95%', 'p']])
        return self.cph

    def check_ph_assumption(self):
        """检查等比例风险假设 (Schoenfeld residuals)"""
        if self.cph is None:
            print("请先运行 Cox 回归！")
            return
        
        print("\n--- PH Assumption Test (Schoenfeld Residuals) ---")
        results = proportional_hazard_test(self.cph, self.df[self.cph.columns])
        print(results)
        
        # 绘制残差图
        self.cph.check_assumptions(self.df[self.cph.columns], show_plots=True)
        plt.show()

    def plot_forest(self):
        """绘制 Cox 回归的森林图 (Hazard Ratios)"""
        if self.cph is None:
            print("请先运行 Cox 回归！")
            return
        
        plt.figure(figsize=(10, 6))
        self.cph.plot()
        plt.title('Forest Plot of Hazard Ratios (HR)')
        plt.grid(True, linestyle='--', alpha=0.5)
        plt.show()

    def predict_survival_at_time(self, time_points):
        """
        预测全人群在特定时间点的生存率
        :param time_points: 时间点列表，如 [12, 24, 36]
        """
        if self.cph is None:
            print("请先运行 Cox 回归以获得基准生存函数！")
            return
        
        # 获取基准生存函数
        baseline_survival = self.cph.baseline_survival_
        
        print(f"\n--- Predicted Average Survival Probability ---")
        for t in time_points:
            # 找到最接近的时间点
            idx = (baseline_survival.index - t).abs().argmin()
            prob = baseline_survival.iloc[idx, 0]
            print(f"Time t = {t}: Average Survival Prob ≈ {prob:.2%}")

# ==========================================
# 考试调用指南 (即插即用示例)
# ==========================================
"""
使用步骤：
1. 准备好数据文件 (xlsx 或 csv)。
2. 修改下面的 file_path, time_col, event_col。
3. 运行脚本。

示例代码：
if __name__ == "__main__":
    # --- 1. 设置基础参数 ---
    FILE = "your_data.xlsx"  # 修改为你的文件名
    TIME = "survival_time"   # 修改为时间列名
    EVENT = "status"         # 修改为事件列名 (1=死亡/事件, 0=存活/删失)
    
    # 初始化
    tool = SurvivalAnalysisTool(FILE, TIME, EVENT)
    
    # --- 2. KM 曲线 & Log-rank 检验 ---
    # 如果想看某因素(如 'gender')的分组生存情况
    tool.run_km_analysis(group_col="gender") 
    
    # --- 3. Cox 多因素回归 ---
    # 定义协变量列表
    COVARS = ["age", "gender", "stage", "treatment"]
    tool.run_cox_regression(covariates=COVARS)
    
    # --- 4. 诊断与可视化 ---
    tool.plot_forest()           # 绘制森林图
    tool.check_ph_assumption()   # 检查 PH 假设
    
    # --- 5. 生存率预测 ---
    tool.predict_survival_at_time([12, 24, 36]) # 预测 1/2/3 年生存率
"""
