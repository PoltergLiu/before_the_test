import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import statsmodels.api as sm
from scipy import stats
from sklearn.metrics import roc_curve, auc, confusion_matrix

# =================================================================
# 逻辑回归 (Logistic Regression) 完整实战流程
# =================================================================

def run_logistic_regression(file_path, target_col, feature_cols):
    """
    核心流程: 变量比较 -> 模型拟合 -> OR值计算 -> ROC评价 -> 风险预测
    """
    
    print(f"{'='*20} 1. 数据读取与类型识别 {'='*20}")
    if file_path.endswith('.csv'):
        df = pd.read_csv(file_path)
    else:
        df = pd.read_excel(file_path)
    
    df = df[[target_col] + feature_cols].dropna()
    
    # 自动识别连续变量与分类变量
    cont_vars = [c for c in feature_cols if df[c].dtype in ['int64', 'float64'] and df[c].nunique() > 5]
    cat_vars = [c for c in feature_cols if c not in cont_vars]
    
    print(f"连续变量: {cont_vars}")
    print(f"分类变量: {cat_vars}")
    print("\n")

    print(f"{'='*20} 2. 单因素差异性分析 (初筛) {'='*20}")
    # 2.1 连续变量比较 (T-test)
    for col in cont_vars:
        g0 = df[df[target_col] == 0][col]
        g1 = df[df[target_col] == 1][col]
        t_stat, p = stats.ttest_ind(g0, g1, equal_var=False)
        print(f"连续变量 [{col}] 在结局组间的差异 (T-test): p = {p:.4f}")

    # 2.2 分类变量比较 (Chi-square)
    for col in cat_vars:
        contingency_table = pd.crosstab(df[col], df[target_col])
        chi2, p, dof, expected = stats.chi2_contingency(contingency_table)
        print(f"分类变量 [{col}] 在结局组间的差异 (Chi-square): p = {p:.4f}")
    print("\n")

    print(f"{'='*20} 3. 拟合 Logistic 模型 {'='*20}")
    # 分类变量 Dummy 编码
    df_encoded = pd.get_dummies(df, columns=cat_vars, drop_first=True)
    X_cols = [c for c in df_encoded.columns if c != target_col]
    X = df_encoded[X_cols]
    X = sm.add_constant(X)
    y = df_encoded[target_col]
    
    model = sm.Logit(y, X).fit()
    print(model.summary())

    print(f"\n{'='*20} 4. 优势比 (Odds Ratios, OR) {'='*20}")
    or_results = np.exp(model.conf_int())
    or_results['OR'] = np.exp(model.params)
    or_results['P-value'] = model.pvalues
    or_results.columns = ['Lower 95%', 'Upper 95%', 'OR', 'P-value']
    print(or_results[['OR', 'Lower 95%', 'Upper 95%', 'P-value']])
    print("\n")

    print(f"{'='*20} 5. 模型评价 (ROC & AUC) {'='*20}")
    y_pred_prob = model.predict(X)
    fpr, tpr, _ = roc_curve(y, y_pred_prob)
    roc_auc = auc(fpr, tpr)
    
    plt.figure(figsize=(6, 5))
    plt.plot(fpr, tpr, label=f'ROC curve (AUC = {roc_auc:.3f})')
    plt.plot([0, 1], [0, 1], 'k--')
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title('Receiver Operating Characteristic')
    plt.legend()
    plt.show()
    print(f"AUC 面积: {roc_auc:.3f}\n")

    return model, X_cols

# =================================================================
# 6. 个体风险预测 (Individual Risk Prediction)
# =================================================================

def predict_individual_risk(model, X_cols, input_dict):
    """
    输入:
    - model: 训练好的 statsmodels Logit 对象
    - X_cols: 模型训练时用到的所有特征列名 (含 Dummy 后的列名)
    - input_dict: 个体的数据字典, 如 {'age': 65, 'bmi': 28, 'smoking_Yes': 1}
    """
    print(f"{'='*20} 7. 个体风险预测 {'='*20}")
    
    # 创建一个全为 0 的 Series，索引为模型特征列
    test_patient = pd.Series(0, index=X_cols)
    
    # 填充输入的数据
    for key, value in input_dict.items():
        if key in test_patient.index:
            test_patient[key] = value
        else:
            print(f"警告: 变量 [{key}] 不在模型特征中，已被忽略。")
            
    # 添加常数项
    test_patient_with_const = np.append([1], test_patient.values)
    
    # 计算概率: p = 1 / (1 + exp(-z))
    risk_prob = model.predict(test_patient_with_const)[0]
    
    print(f"该个体的预测发病概率为: {risk_prob:.2%}")
    return risk_prob

# =================================================================
# 考试快速调用示例
# =================================================================
if __name__ == "__main__":
    # 1. 模拟数据
    data = pd.DataFrame({
        'outcome': np.random.randint(0, 2, 100),
        'age': np.random.normal(50, 10, 100),
        'bmi': np.random.normal(24, 4, 100),
        'smoking': np.random.choice(['Yes', 'No'], 100)
    })
    data.to_csv("exam_data.csv", index=False)
    
    # 2. 运行逻辑回归主流程
    # 返回 model 和 X_cols 供后续预测使用
    model, trained_cols = run_logistic_regression(
        file_path="exam_data.csv",
        target_col='outcome',
        feature_cols=['age', 'bmi', 'smoking']
    )
    
    # 3. 预测新个体的风险
    # 注意: 分类变量要使用 Dummy 后的列名，如 'smoking_Yes'
    new_patient = {
        'age': 65,
        'bmi': 30,
        'smoking_Yes': 1  # 1 代表是吸烟者
    }
    predict_individual_risk(model, trained_cols, new_patient)


'''
### 脚本新增功能说明
1. 连续变量与分类变量分析 ：
   - 脚本现在会自动识别变量类型。
   - 在回归分析之前，会先进行 单因素差异性分析 ：连续变量使用 T 检验 ，分类变量使用 卡方检验 。这有助于您在构建多因素模型前筛选出有统计学意义的候选变量。
2. 个体风险预测 ：
   - 新增了 predict_individual_risk 函数。
   - 该函数允许您输入一个特定个体的数据（字典格式），并利用拟合好的逻辑回归模型计算该个体的 发病/事件发生概率 。
### 脚本使用指南（考试速查）
1. 准备阶段

- 确保您的 Excel 或 CSV 文件中，结局变量（Y）已经是 0 和 1 （例如：1=患病，0=健康）。
- 将脚本中的 file_path 指向您的数据文件。
2. 运行回归流程

- 调用 run_logistic_regression 函数。
- 参数 ：传入文件路径、目标列名（结局变量）和特征列名列表。
- 输出 ：
  - Step 2 会告诉你哪些变量在单因素分析中是显著的（P < 0.05）。
  - Step 4 提供了 OR 值 及其置信区间。这是写论文/答题的核心数据。
  - Step 5 绘制 ROC 曲线 并给出 AUC 。如果 AUC > 0.7，说明模型预测效果良好。
3. 进行个体风险预测

- 使用回归流程返回的 model 和 trained_cols 。
- 构建一个包含新患者数据的字典。
- 特别注意（坑点） ：
  - 连续变量直接写原名，如 'age': 60 。
  - 分类变量必须使用 Dummy 编码后的列名 。例如：如果原列名是 smoking ，且有 Yes/No ，脚本生成的列名通常是 smoking_Yes 。如果您想预测“吸烟者”，则传入 {'smoking_Yes': 1} 。
4. 结果解读

- OR > 1 ：危险因素（增加风险）。
- OR < 1 ：保护因素（降低风险）。
- P < 0.05 ：该因素的影响具有统计学意义。
'''