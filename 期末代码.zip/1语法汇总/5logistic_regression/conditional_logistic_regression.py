import pandas as pd
import numpy as np
from lifelines import CoxPHFitter

# =================================================================
# 条件逻辑回归 (Conditional Logistic Regression) 完整实战流程
# 场景: 配对病例对照研究 (Matched Case-Control Study)
# =================================================================

def run_conditional_logistic(file_path, target_col, match_id_col, feature_cols):
    """
    输入:
    - file_path: 数据路径
    - target_col: 结局变量 (1=病例, 0=对照)
    - match_id_col: 配对组 ID (如 'pair_id', 同一对病例和对照拥有相同的 ID)
    - feature_cols: 预测因子列表
    """
    print(f"{'='*20} 1. 数据加载与配对检查 {'='*20}")
    if file_path.endswith('.csv'):
        df = pd.read_csv(file_path)
    else:
        df = pd.read_excel(file_path)
        
    # 提取必要列并删除缺失
    df = df[[target_col, match_id_col] + feature_cols].dropna()
    
    print(f"总样本量: {len(df)}")
    print(f"配对组数量: {df[match_id_col].nunique()}")
    print("\n")

    print(f"{'='*20} 2. 拟合条件逻辑回归模型 {'='*20}")
    # 原理说明:
    # 条件逻辑回归在数学上等同于将每一对(或每一组)配对数据看作一个地层(Stratum)的 Cox 模型。
    # 我们为所有人设置一个虚拟的、相等的生存时间(如 1)。
    df_clr = df.copy()
    df_clr['dummy_time'] = 1 
    
    # 自动处理分类变量 (Dummy Coding)
    df_encoded = pd.get_dummies(df_clr, columns=[c for c in feature_cols if df_clr[c].dtype == 'object'], drop_first=True)
    
    # 确定编码后的特征列
    final_features = [c for c in df_encoded.columns if c not in [target_col, match_id_col, 'dummy_time']]
    
    # 使用 CoxPHFitter，并将 match_id 设为 strata
    cph = CoxPHFitter()
    cph.fit(
        df_encoded[[target_col, 'dummy_time', match_id_col] + final_features],
        duration_col='dummy_time',
        event_col=target_col,
        strata=[match_id_col]
    )
    
    cph.print_summary()
    print("\n")

    print(f"{'='*20} 3. 结果解读 (Odds Ratios, OR) {'='*20}")
    # 在条件逻辑回归中，Cox 模型的 Hazard Ratio (HR) 即为 Odds Ratio (OR)
    summary = cph.summary[['exp(coef)', 'exp(coef) lower 95%', 'exp(coef) upper 95%', 'p']]
    summary.columns = ['OR', 'Lower 95%', 'Upper 95%', 'P-value']
    print(summary)
    
    return cph

# =================================================================
# 考试快速调用示例
# =================================================================
if __name__ == "__main__":
    # 1. 构造 1:1 配对模拟数据
    # 假设有 50 对病人，每对包含 1 个病例和 1 个对照，匹配了年龄和性别
    n_pairs = 50
    pair_ids = np.repeat(np.arange(n_pairs), 2)
    outcome = np.tile([1, 0], n_pairs) # 每对中一个是 1 (病例)，一个是 0 (对照)
    
    data = pd.DataFrame({
        'pair_id': pair_ids,
        'is_case': outcome,
        'exposure_score': np.random.normal(0, 1, n_pairs * 2) + outcome * 0.5, # 病例的暴露分数略高
        'diet_type': np.random.choice(['Healthy', 'Unhealthy'], n_pairs * 2)
    })
    
    data.to_csv("matched_data.csv", index=False)
    
    # 2. 调用分析
    # target_col: 结局 (1/0)
    # match_id_col: 配对 ID
    # feature_cols: 感兴趣的暴露因素
    run_conditional_logistic(
        file_path="matched_data.csv",
        target_col='is_case',
        match_id_col='pair_id',
        feature_cols=['exposure_score', 'diet_type']
    )


'''
为什么需要条件逻辑回归？ 在生物医学统计中，如果你采用了 配对设计 （如：为每一个肺癌患者匹配一个同年龄、同性别的健康人），普通的逻辑回归会因为忽略了这种“成对”的关联性而导致结果偏差。条件逻辑回归通过在“配对组内”进行比较，消除了匹配因素的影响。

脚本核心功能

- 1. 自动配对识别 ：通过 match_id_col （配对 ID）识别哪些行属于同一个配对组。
- 2. Cox 转换计算 ：
  - 脚本巧妙地利用了 lifelines 库中的 CoxPHFitter 。
  - 原理 ：将每个配对组设为一个“地层 (Strata)”，并将生存时间设为固定值。这种方法计算出的 Hazard Ratio (HR) 在数学上完全等同于条件逻辑回归的 Odds Ratio (OR) 。
- 3. 结果解读 ：
  - 输出模型摘要，包含变量系数、OR 值、置信区间及 P 值。
考试实战建议

- 数据格式 ：确保每一对病例和对照在数据集中都有一个共同的 pair_id 。
- OR 的意义 ：与普通逻辑回归一致，代表暴露因素与患病风险的关联强度。
- 适用场景 ：只要题目提到“1:1 匹配”、“配对病例对照”，就必须使用这个脚本，而不是普通的 sm.Logit 。
'''