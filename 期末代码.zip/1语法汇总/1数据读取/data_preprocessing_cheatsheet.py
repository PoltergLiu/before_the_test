import pandas as pd
import numpy as np
import re

# =================================================================
# 1. 数据读取与概览 (File I/O & Inspection)
# =================================================================

def load_and_inspect(file_path):
    """
    读取数据并进行初步检查与列名标准化
    支持 .csv 和 .xlsx/.xls
    """
    # 1. 读取数据 (尝试不同编码防止中文报错)
    if file_path.endswith('.csv'):
        try:
            df = pd.read_csv(file_path, encoding='utf-8')
        except UnicodeDecodeError:
            df = pd.read_csv(file_path, encoding='gbk')
    elif file_path.endswith(('.xlsx', '.xls')):
        df = pd.read_excel(file_path)
    else:
        raise ValueError("不支持的文件格式，请使用 csv 或 excel")

    # 2. 自动打印概览信息
    print("--- 数据前5行 (Head) ---")
    display(df.head()) # Jupyter 中使用 display 更美观，脚本环境改用 print
    print(f"\n--- 数据行列数 (Shape): {df.shape} ---")
    print("\n--- 数据类型与缺失情况 (Info) ---")
    df.info()

    # 3. 标准化列名: 小写 + 下划线连接
    # 例如: 'Body Weight (kg)' -> 'body_weight_kg'
    df.columns = [re.sub(r'[^a-zA-Z0-9]', '_', col.lower()).strip('_') for col in df.columns]
    df.columns = [re.sub(r'_+', '_', col) for col in df.columns] # 替换连续的下划线
    print("\n--- 标准化后的列名 ---")
    print(df.columns.tolist())
    
    return df

# 使用示例:
# df = load_and_inspect('data.csv')


# =================================================================
# 2. 缺失值处理 (Handling Missing Data)
# =================================================================

def handle_missing_data(df):
    """
    处理 DataFrame 中的奇怪缺失值并提供填充方案
    """
    # 1. 强制替换奇怪字符为 np.nan
    weird_chars = ['NA', 'null', '.', '?', ' ', '']
    df = df.replace(weird_chars, np.nan)
    
    # 2. 统计每列缺失值
    print("--- 各列缺失值统计 ---")
    print(df.isnull().sum())

    # 3. 提供两套方案 (根据考试要求选择其一)
    
    # --- 方案 A: 删除任何包含缺失值的行 ---
    # df_cleaned = df.dropna().reset_index(drop=True)
    
    # --- 方案 B: 智能填充 ---
    df_filled = df.copy()
    for col in df_filled.columns:
        if df_filled[col].dtype in ['float64', 'int64']:
            # 数值列用中位数填充 (比均值更稳健)
            df_filled[col] = df_filled[col].fillna(df_filled[col].median())
        else:
            # 分类列用众数填充
            mode_val = df_filled[col].mode()
            if not mode_val.empty:
                df_filled[col] = df_filled[col].fillna(mode_val[0])
                
    return df_filled

# 使用示例:
# df = handle_missing_data(df)


# =================================================================
# 3. 数据清洗与类型转换 (Cleaning & Type Conversion)
# =================================================================

def clean_numeric_column(df, column_name):
    """
    去掉单位(如 '80kg')并转为 float
    """
    # 使用正则保留数字和小数点
    df[column_name] = df[column_name].astype(str).str.extract(r'(\d+\.?\d*)').astype(float)
    return df

def clean_categorical_column(df, column_name):
    """
    统一分类变量格式: 小写 + 去空格
    """
    df[column_name] = df[column_name].astype(str).str.lower().str.strip()
    return df

# 使用示例:
# df = clean_numeric_column(df, 'weight')
# df = clean_categorical_column(df, 'sex')


# =================================================================
# 4. 衍生变量计算 (Feature Engineering)
# =================================================================

def add_biomedical_features(df):
    """
    常见生物统计变量计算示例 (如 BMI 分组)
    """
    # 1. 列计算: BMI = weight(kg) / height(m)^2
    # 注意: 如果身高是cm，记得除以100
    if 'weight' in df.columns and 'height' in df.columns:
        df['bmi'] = df['weight'] / (df['height']**2)

    # 2. 数据分组 (分箱): pd.cut
    bins = [0, 18.5, 24, np.inf]
    labels = ['Underweight', 'Normal', 'Overweight']
    df['bmi_group'] = pd.cut(df['bmi'], bins=bins, labels=labels)

    # 3. 标签编码: 映射为数字 (0, 1) 用于逻辑回归
    # 假设 'group' 列有 'Control' 和 'Treatment'
    if 'group' in df.columns:
        mapping = {'control': 0, 'treatment': 1}
        # 确保先清洗过大小写
        df['group_code'] = df['group'].str.lower().map(mapping)
        
    return df


# =================================================================
# 5. 数据筛选与子集提取 (Filtering & Subsetting)
# =================================================================

"""
常用的 5 种筛选语法速查:
"""

# 1. 单条件筛选 (Age > 60)
# subset1 = df[df['age'] > 60]

# 2. 多条件筛选 (Age > 60 且性别为女)
# subset2 = df[(df['age'] > 60) & (df['sex'] == 'female')]

# 3. 排除法 (不要 Placebo 组)
# subset3 = df[df['group'] != 'placebo']

# 4. 选取特定列
# df_new = df[['id', 'age', 'bmi', 'outcome']]

# 5. 重置索引 (重要: 防止后续合并或绘图报错)
# df_new = df_new.reset_index(drop=True)
