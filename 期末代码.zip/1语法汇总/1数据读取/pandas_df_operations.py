# -*- coding: utf-8 -*-
"""
生物医学统计 - Pandas DataFrame 常用操作大全 (即插即用)
涵盖：数据查看、筛选、清洗、转换、合并及考场常用技巧
"""

import pandas as pd
import numpy as np

# ==========================================
# 1. 数据读取与基础查看
# ==========================================
def basic_viewing(df):
    print("--- 基础信息 ---")
    print(df.info())          # 查看列名、非空计数、数据类型
    print("\n--- 统计描述 ---")
    print(df.describe())      # 均值、标准差、四分位数
    print("\n--- 缺失值统计 ---")
    print(df.isnull().sum())  # 每列缺失值数量
    print("\n--- 前5行预览 ---")
    print(df.head())

# ==========================================
# 2. 数据筛选 (考场高频)
# ==========================================
def data_filtering(df):
    # 2.1 按列名选取
    sub_df = df[['age', 'gender', 'outcome']]
    
    # 2.2 按条件筛选行
    # 示例：选取年龄大于 60 且为男性的行
    elderly_men = df[(df['age'] > 60) & (df['gender'] == 'Male')]
    
    # 2.3 模糊匹配 (筛选包含特定字符的列)
    cols_with_time = [c for c in df.columns if 'time' in c.lower()]
    
    # 2.4 排除缺失值
    clean_df = df.dropna(subset=['outcome']) # 仅删除结局变量为空的行

# ==========================================
# 3. 变量转换与新增列
# ==========================================
def column_transform(df):
    # 3.1 连续变量转分类变量 (例如：年龄转年龄组)
    df['age_group'] = pd.cut(df['age'], 
                             bins=[0, 18, 65, 120], 
                             labels=['Minor', 'Adult', 'Elderly'])
    
    # 3.2 逻辑判断 (例如：1=高血压, 0=正常)
    df['is_hypertension'] = np.where(df['SBP'] >= 140, 1, 0)
    
    # 3.3 字典映射 (例如：编码性别)
    gender_map = {'Male': 1, 'Female': 0}
    df['gender_code'] = df['gender'].map(gender_map)
    
    # 3.4 哑变量处理 (重要：回归分析前常用)
    df_with_dummies = pd.get_dummies(df, columns=['treatment'], drop_first=True)

# ==========================================
# 4. 数据清洗与缺失值处理
# ==========================================
def data_cleaning(df):
    # 4.1 填充缺失值
    df['age'] = df['age'].fillna(df['age'].mean())    # 均值填充
    df['gender'] = df['gender'].fillna(df['gender'].mode()[0]) # 众数填充
    
    # 4.2 列名重命名
    df = df.rename(columns={'OS.time': 'time', 'OS.status': 'event'})
    
    # 4.3 删除重复行
    df = df.drop_duplicates()
    
    # 4.4 去除字符串空格
    if df['id'].dtype == 'object':
        df['id'] = df['id'].str.strip()

# ==========================================
# 5. 分组统计 (常用于描述性统计)
# ==========================================
def group_stats(df):
    # 按组计算均值和标准差
    summary = df.groupby('group_col')['value_col'].agg(['mean', 'std', 'count']).reset_index()
    return summary

# ==========================================
# 6. 数据合并
# ==========================================
def data_merging(df1, df2):
    # 按 ID 合并 (类似 SQL join)
    merged = pd.merge(df1, df2, on='patient_id', how='left')
    return merged

# ==========================================
# 考场实用技巧 (Cheat Sheet)
# ==========================================
"""
1. 快速导出清洗后的数据:
   df.to_excel("cleaned_data.xlsx", index=False)

2. 查看某列的所有唯一值 (确认分类变量):
   df['treatment'].unique()

3. 统计各类别频数:
   df['outcome'].value_counts()

4. 快速计算相关系数矩阵:
   df.corr()

5. 设置某列为索引:
   df.set_index('patient_id', inplace=True)
"""

if __name__ == "__main__":
    # 示例用法
    print("Pandas 常用操作指南已准备就绪。")
    # data = pd.read_excel("your_data.xlsx")
    # basic_viewing(data)
