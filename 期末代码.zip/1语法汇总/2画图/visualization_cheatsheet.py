import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from lifelines import KaplanMeierFitter

# ==========================================
# 0. 全局样式设置 (考试建议加上，图表更专业)
# ==========================================
sns.set(style="whitegrid")
plt.rcParams['font.sans-serif'] = ['SimHei']  # 中文显示
plt.rcParams['axes.unicode_minus'] = False     # 负号显示

# ==========================================
# 1. 比较分布 (箱线图、小提琴图)
# 场景: 比较不同组 (Group) 之间的连续变量 (Value) 差异
# ==========================================

def plot_distribution_comparison(df, x_col, y_col, hue_col=None):
    """
    绘制箱线图和小提琴图的组合
    """
    plt.figure(figsize=(12, 5))
    
    # 1. 箱线图 (展示中位数、四分位数、离群点)
    plt.subplot(1, 2, 1)
    sns.boxplot(x=x_col, y=y_col, hue=hue_col, data=df, palette="Set2")
    plt.title(f"{y_col} Boxplot by {x_col}")
    
    # 2. 小提琴图 (展示数据密度分布)
    plt.subplot(1, 2, 2)
    sns.violinplot(x=x_col, y=y_col, hue=hue_col, data=df, split=True, inner="quart", palette="Pastel1")
    plt.title(f"{y_col} Violin Plot by {x_col}")
    
    plt.tight_layout()
    plt.show()

# ==========================================
# 2. 相关性与回归 (散点图)
# 场景: 查看两个连续变量之间的关系，并添加回归线
# ==========================================

def plot_regression(df, x_col, y_col, group_col=None):
    """
    带回归线和边际分布的散点图
    """
    if group_col:
        # 按组分颜色绘制回归线
        g = sns.lmplot(x=x_col, y=y_col, hue=group_col, data=df, aspect=1.5, height=6)
    else:
        # 单一回归线 + 边际直方图
        g = sns.jointplot(x=x_col, y=y_col, data=df, kind="reg", color="m", height=7)
    
    plt.subplots_adjust(top=0.9)
    plt.suptitle(f"Regression: {y_col} vs {x_col}")
    plt.show()

# ==========================================
# 3. 频数与占比 (条形图、计数图)
# 场景: 统计分类变量的分布 (如各组人数、患病率)
# ==========================================

def plot_counts(df, x_col, hue_col=None):
    """
    计数条形图
    """
    plt.figure(figsize=(8, 5))
    sns.countplot(x=x_col, hue=hue_col, data=df, palette="viridis")
    plt.title(f"Counts of {x_col}")
    plt.show()

# ==========================================
# 4. 变量分布 (直方图、密度图)
# 场景: 检查单变量的正态性
# ==========================================

def plot_univariate_dist(df, col):
    """
    直方图 + 核密度估计 (KDE)
    """
    plt.figure(figsize=(8, 5))
    sns.histplot(df[col], kde=True, color="skyblue", bins=30)
    plt.title(f"Distribution of {col}")
    plt.show()

# ==========================================
# 5. 矩阵可视化 (热力图)
# 场景: 展示多个指标之间的相关系数矩阵
# ==========================================

def plot_correlation_heatmap(df, cols):
    """
    相关系数热力图
    """
    plt.figure(figsize=(10, 8))
    corr = df[cols].corr()
    mask = np.triu(np.ones_like(corr, dtype=bool)) # 掩盖上半部分
    sns.heatmap(corr, mask=mask, annot=True, fmt=".2f", cmap='coolwarm', center=0)
    plt.title("Correlation Matrix")
    plt.show()

# ==========================================
# 6. 生存分析 (Kaplan-Meier Plot)
# 场景: 临床随访数据，比较不同组的生存率
# ==========================================

def plot_km_survival(df, time_col, event_col, group_col):
    """
    绘制 KM 生存曲线
    """
    kmf = KaplanMeierFitter()
    plt.figure(figsize=(10, 6))
    
    for name, grouped_df in df.groupby(group_col):
        kmf.fit(grouped_df[time_col], grouped_df[event_col], label=name)
        kmf.plot_survival_function()
        
    plt.title("Kaplan-Meier Survival Curves")
    plt.xlabel("Time (days/months)")
    plt.ylabel("Survival Probability")
    plt.grid(True)
    plt.show()

# --- 使用示例 (考试时可删掉) ---
if __name__ == "__main__":
    # 模拟数据
    test_df = pd.DataFrame({
        'group': ['A']*50 + ['B']*50,
        'sex': ['M', 'F']*50,
        'bmi': np.random.normal(24, 3, 100),
        'age': np.random.normal(50, 10, 100),
        'time': np.random.exponential(20, 100),
        'event': np.random.randint(0, 2, 100)
    })
    
    # 1. 比较不同组的 BMI
    # plot_distribution_comparison(test_df, 'group', 'bmi', hue_col='sex')
    
    # 2. 年龄与 BMI 的相关性
    # plot_regression(test_df, 'age', 'bmi')
    
    # 3. 相关性矩阵
    # plot_correlation_heatmap(test_df, ['bmi', 'age', 'time'])
    
    # 4. 生存曲线
    # plot_km_survival(test_df, 'time', 'event', 'group')
