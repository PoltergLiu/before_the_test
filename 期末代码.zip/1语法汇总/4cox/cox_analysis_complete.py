import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from lifelines import CoxPHFitter, KaplanMeierFitter

# =================================================================
# Cox 比例风险回归分析 (Cox Proportional Hazards) 完整实战流程
# =================================================================

def run_cox_analysis(file_path, time_col, event_col, covariates, predict_at_times=None):
    """
    输入:
    - file_path: .xlsx 或 .csv 文件路径
    - time_col: 生存时间列名
    - event_col: 结局事件列名 (1=事件发生, 0=删失)
    - covariates: 协变量列表
    - predict_at_times: 想要计算生存率的时间点列表, 如 [12, 24, 36] (代表1年, 2年, 3年)
    """
    
    print(f"{'='*20} 1. 读取与数据预处理 {'='*20}")
    # 自动识别文件格式
    df = pd.read_csv(file_path) if file_path.endswith('.csv') else pd.read_excel(file_path)
    
    # 提取需要的列并处理缺失值
    df = df[[time_col, event_col] + covariates].dropna()
    
    # --- 哑变量处理 (Dummy Coding) ---
    # 自动识别 object 类型或类别数量较少的列作为分类变量
    cat_cols = [c for c in covariates if df[c].dtype == 'object' or df[c].nunique() < 5]
    print(f"识别到分类变量 (将进行哑变量处理): {cat_cols}")
    
    # drop_first=True: 关键! 每一个分类变量生成 (n-1) 个哑变量，防止多重共线性
    df_encoded = pd.get_dummies(df, columns=cat_cols, drop_first=True)
    
    print(f"处理后数据维度: {df_encoded.shape}")
    print(f"模型特征列: {df_encoded.columns.tolist()}")
    print("\n")

    print(f"{'='*20} 2. 拟合 Cox 模型 {'='*20}")
    cph = CoxPHFitter()
    cph.fit(df_encoded, duration_col=time_col, event_col=event_col)
    cph.print_summary()
    print("\n")

    print(f"{'='*20} 3. 结果解读 (Hazard Ratios) {'='*20}")
    results = cph.summary[['exp(coef)', 'exp(coef) lower 95%', 'exp(coef) upper 95%', 'p']]
    results.columns = ['HR', 'HR_Lower_CI', 'HR_Upper_CI', 'P-value']
    print(results)
    print("\n")

    # --- 核心新增: 计算特定时段的生存率 ---
    if predict_at_times:
        print(f"{'='*20} 4. 特定时间点生存率预测 {'='*20}")
        # 计算全样本的平均生存曲线
        survival_prob = cph.predict_survival_function(df_encoded)
        
        for t in predict_at_times:
            # 找到最接近 t 的时间点
            actual_t = survival_prob.index[np.abs(survival_prob.index - t).argmin()]
            avg_surv = survival_prob.loc[actual_t].mean()
            print(f"时间点 t = {t} 的全人群平均生存率约为: {avg_surv:.2%}")
        print("\n")

    print(f"{'='*20} 5. 可视化 {'='*20}")
    # 5.1 森林图
    plt.figure(figsize=(10, 6))
    cph.plot()
    plt.title("Cox Model - Hazard Ratios (Forest Plot)")
    plt.show()

    # 5.2 KM 曲线对比 (按第一个协变量分层)
    main_var = covariates[0]
    plt.figure(figsize=(10, 6))
    kmf = KaplanMeierFitter()
    for name, grouped_df in df.groupby(main_var):
        kmf.fit(grouped_df[time_col], grouped_df[event_col], label=f"{main_var}={name}")
        kmf.plot_survival_function()
    plt.title(f"KM Survival Curves by {main_var}")
    plt.ylabel("Survival Probability")
    plt.show()

    return cph

# =================================================================
# 考试运行指南 (How to run this code)
# =================================================================
"""
【考试三步走】
1. 准备数据: 确保你的 Excel 文件中，生存时间是数值，结局是 0/1。
2. 修改参数: 
   - file_path: 你的文件名 (如 'data.xlsx')
   - time_col: 时间列名 (如 'Time')
   - event_col: 结局列名 (如 'Status')
   - covariates: 你想分析的因素 (如 ['Age', 'Sex', 'Stage'])
   - predict_at_times: 题目要求的 survival rate 时间点 (如 [12, 24])
3. 直接运行: 脚本会自动处理哑变量、计算 HR 值、绘制森林图并告诉你特定时间的生存率。
"""

if __name__ == "__main__":
    # 模拟数据测试
    test_data = pd.DataFrame({
        'OS_time': np.random.exponential(30, 100),
        'Status': np.random.randint(0, 2, 100),
        'Age': np.random.normal(55, 10, 100),
        'Stage': np.random.choice(['I', 'II', 'III'], 100), # 多分类变量
        'Treatment': np.random.choice(['A', 'B'], 100)
    })
    test_data.to_excel("exam_survival_data.xlsx", index=False)
    
    # 运行分析
    run_cox_analysis(
        file_path="exam_survival_data.xlsx",
        time_col='OS_time',
        event_col='Status',
        covariates=['Age', 'Stage', 'Treatment'],
        predict_at_times=[12, 24, 36] # 计算12、24、36个月生存率
    )


'''
第一步：定位到脚本末尾 找到代码中的 if __name__ == "__main__": 部分。

第二步：修改 run_cox_analysis 的参数

- file_path : 填入老师给的数据文件名（例如 "data.xlsx" ）。
- time_col : 填入代表“时间”的列名。
- event_col : 填入代表“结局/状态”的列名（通常 1 代表死亡/发病，0 代表生存/删失）。
- covariates : 填入你想要分析的影响因素列表，例如 ['年龄', '性别', '临床分期'] 。
- predict_at_times : 如果题目问“2年生存率是多少？”，你就填入 [24] （假设单位是月）。
第三步：解读输出结果

- HR (Hazard Ratio) : 如果 HR > 1，该因素是危险因素；如果 HR < 1，是保护因素。
- P-value : 如果 P < 0.05，说明该因素对生存时间有显著影响。
- 特定时间生存率 : 脚本会在控制台直接打印出类似 时间点 t = 24 的全人群平均生存率约为: 75.20% 的结果。
'''