# -*- coding: utf-8 -*-
"""
生物医学统计 - 贝叶斯后验推断 (Slide 8-17 专用模板)
涵盖：正态-正态模型、Beta-二项模型(含VE计算)、Dirichlet-多项模型(含OR计算)
"""

import numpy as np
from scipy import stats

# ==========================================
# 1. 正态-正态模型 (Normal-Normal) (Slide 8-10)
# ==========================================
def normal_normal_update(prior_mean, prior_std, obs_data, obs_std):
    """
    已知先验 N(mu0, tau0^2) 和观测值 x (其误差为 sigma), 计算后验 N(mu1, tau1^2)
    
    参数:
    - prior_mean: 先验均值 (mu0)
    - prior_std: 先验标准差 (tau0)
    - obs_data: 观测值 (x) 或 观测均值 (x_bar)
    - obs_std: 观测的标准差 (sigma) 或 均值的标准误 (sigma/sqrt(n))
    """
    # 计算精度 (precision = 1/variance)
    precision_prior = 1 / (prior_std**2)
    precision_obs = 1 / (obs_std**2)
    
    # 1. 后验均值 (加权平均)
    posterior_mean = (precision_prior * prior_mean + precision_obs * obs_data) / (precision_prior + precision_obs)
    
    # 2. 后验方差
    posterior_var = 1 / (precision_prior + precision_obs)
    posterior_std = np.sqrt(posterior_var)
    
    # 3. 95% 可靠区间 (Credible Interval)
    ci_low, ci_high = stats.norm.interval(0.95, loc=posterior_mean, scale=posterior_std)
    
    print(f"--- 正态-正态模型分析 ---")
    print(f"先验: N({prior_mean}, {prior_std}^2)")
    print(f"观测: {obs_data} (误差={obs_std})")
    print(f"后验均值: {posterior_mean:.4f}")
    print(f"后验标准差: {posterior_std:.4f}")
    print(f"95% 可靠区间: [{ci_low:.4f}, {ci_high:.4f}]")
    return posterior_mean, posterior_std

# ==========================================
# 2. Beta-二项模型 (Beta-Binomial) (Slide 11-14)
# ==========================================
def beta_binomial_update(alpha_prior, beta_prior, n_trials, k_successes):
    """
    计算 Beta-二项后验
    参数:
    - alpha_prior, beta_prior: 先验 Beta 参数
    - n_trials: 试验总次数
    - k_successes: 成功/发生次数
    """
    # 1. 后验参数更新 (简单加法)
    alpha_post = alpha_prior + k_successes
    beta_post = beta_prior + n_trials - k_successes
    
    # 2. 后验统计量
    post_mean = alpha_post / (alpha_post + beta_post)
    
    # 3. 95% 可靠区间
    ci_low, ci_high = stats.beta.interval(0.95, alpha_post, beta_post)
    
    print(f"--- Beta-二项模型分析 ---")
    print(f"后验分布: Beta({alpha_post}, {beta_post})")
    print(f"后验均值: {post_mean:.4f}")
    print(f"95% 可靠区间: [{ci_low:.4f}, {ci_high:.4f}]")
    return alpha_post, beta_post

def calculate_vaccine_efficacy(aru_params, arv_params, n_sim=100000):
    """
    计算疫苗效力 VE = (ARU - ARV) / ARU (Slide 13-14)
    aru_params: (alpha, beta) 未接种组的后验参数
    arv_params: (alpha, beta) 接种组的后验参数
    """
    # 蒙特卡洛模拟
    aru_samples = np.random.beta(aru_params[0], aru_params[1], n_sim)
    arv_samples = np.random.beta(arv_params[0], arv_params[1], n_sim)
    
    ve_samples = (aru_samples - arv_samples) / aru_samples
    
    ve_mean = np.mean(ve_samples)
    ve_ci = np.percentile(ve_samples, [2.5, 97.5])
    
    print(f"--- 疫苗效力 (VE) 分析 ---")
    print(f"VE 均值: {ve_mean:.4%}")
    print(f"VE 95% 可靠区间: [{ve_ci[0]:.4%}, {ve_ci[1]:.4%}]")
    return ve_samples

# ==========================================
# 3. 2x2 列联表分析 (Dirichlet-Multinomial) (Slide 15-17)
# ==========================================
def analyze_2x2_bayesian(table, alpha_prior=None, n_sim=100000):
    """
    2x2 列联表的贝叶斯分析，计算 RD, RR, OR
    table: np.array([[a, b], [c, d]]) -> a=暴露且患病, b=暴露但不患病...
    """
    if alpha_prior is None:
        alpha_prior = np.ones_like(table) # 无信息先验 (All ones)
        
    # 后验参数更新
    post_params = table + alpha_prior
    
    # 模拟两组的患病概率
    p1 = np.random.beta(post_params[0,0], post_params[0,1], n_sim)
    p2 = np.random.beta(post_params[1,0], post_params[1,1], n_sim)
    
    # 计算统计量
    rd = p1 - p2
    rr = p1 / p2
    odds_ratio = (p1/(1-p1)) / (p2/(1-p2))
    
    print(f"--- 2x2 列联表贝叶斯分析 ---")
    print(f"RD 均值: {np.mean(rd):.4f} [95% CI: {np.percentile(rd, 2.5):.4f}, {np.percentile(rd, 97.5):.4f}]")
    print(f"RR 均值: {np.mean(rr):.4f} [95% CI: {np.percentile(rr, 2.5):.4f}, {np.percentile(rr, 97.5):.4f}]")
    print(f"OR 均值: {np.mean(odds_ratio):.4f} [95% CI: {np.percentile(odds_ratio, 2.5):.4f}, {np.percentile(odds_ratio, 97.5):.4f}]")
    return {"RD": rd, "RR": rr, "OR": odds_ratio}

# ==========================================
# 考试快速调用示例 (按讲义参数)
# ==========================================
if __name__ == "__main__":
    print(">>> 案例 1: 体重估计 (Slide 9)")
    # 先验 N(49.5, 0.9^2), 观测 x=47, 误差 sigma=1
    normal_normal_update(prior_mean=49.5, prior_std=0.9, obs_data=47, obs_std=1.0)
    
    print("\n>>> 案例 2: 死亡率估计 (Slide 12)")
    # 先验 Beta(1.64, 20.3), 数据 3/10
    beta_binomial_update(1.64, 20.3, 10, 3)
    
    print("\n>>> 案例 3: 列联表分析 (Slide 17)")
    # 假设数据表: [[10, 90], [5, 95]]
    data = np.array([[10, 90], [5, 95]])
    analyze_2x2_bayesian(data)
