# -*- coding: utf-8 -*-
"""
生物医学统计 - 概率基础与统计决策 (Slide 3-7 专用模板)
涵盖：贝叶斯后验计算、新冠检测悖论分析、混采检测期望与最优决策
"""

import numpy as np

# ==========================================
# 1. 贝叶斯后验概率计算器 (Slide 3-4)
# ==========================================
def bayes_posterior(sensitivity, specificity, prevalence):
    """
    计算检测结果为阳性时，真实患病的概率 P(D|+)
    
    参数:
    - sensitivity (灵敏度): P(+|D), 病人被检出阳性的概率
    - specificity (特异性): P(-|D_bar), 健康人被检出阴性的概率
    - prevalence (患病率/先验): P(D), 人群中的患病比例
    """
    # 1. P(D) 患病; P(D_bar) 健康
    p_d = prevalence
    p_d_bar = 1 - prevalence
    
    # 2. P(+|D) 灵敏度; P(+|D_bar) 假阳性率 (1 - 特异性)
    p_pos_given_d = sensitivity
    p_pos_given_d_bar = 1 - specificity
    
    # 3. 全概率公式: P(+) 观察到阳性的总概率
    p_positive = (p_pos_given_d * p_d) + (p_pos_given_d_bar * p_d_bar)
    
    # 4. 贝叶斯公式: P(D|+) 阳性者真实患病的概率 (后验)
    posterior = (p_pos_given_d * p_d) / p_positive
    
    print(f"--- 贝叶斯分析 ---")
    print(f"先验患病率 P(D): {prevalence:.4%}")
    print(f"检测阳性总概率 P(+): {p_positive:.4%}")
    print(f"阳性真实患病率 P(D|+): {posterior:.4%}")
    print(f"假阳性率 P(D_bar|+): {1-posterior:.4%}")
    return posterior

# ==========================================
# 2. 混采检测 (Group Testing) 期望计算器 (Slide 5-6)
# ==========================================
def group_testing_expectation(pi, s, N=1000):
    """
    计算混采检测的期望检测次数
    
    参数:
    - pi (阳性率): 人群中的阳性率
    - s (组大小): 每组多少人混采
    - N (总人数): 总样本量 (默认1000)
    """
    # 一组人全为阴性的概率
    p_all_negative = (1 - pi) ** s
    
    # 一组中至少有一个阳性的概率
    p_at_least_one_pos = 1 - p_all_negative
    
    # 单组期望次数: 1次(初筛) + s次(如果初筛阳性则重测) * P(初筛阳性)
    e_single_group = 1 + s * p_at_least_one_pos
    
    # 总期望次数 = (N/s) 组 * 每组期望
    total_expectation = (N / s) * e_single_group
    
    # 节省比例
    savings = (N - total_expectation) / N
    
    print(f"--- 混采检测分析 (组大小 s={s}) ---")
    print(f"单组全阴概率: {p_all_negative:.4%}")
    print(f"单组期望次数: {e_single_group:.4f}")
    print(f"总期望检测次数 ({N}人): {total_expectation:.2f}")
    print(f"相比单采节省比例: {savings:.2%}")
    return total_expectation

# ==========================================
# 3. 最优组大小决策 (Slide 7)
# ==========================================
def find_optimal_group_size(pi, N=1000):
    """
    利用近似公式 s ≈ 1/sqrt(pi) 寻找理论最优组大小
    并遍历周边整数寻找实际最优
    """
    # 1. 理论最优 (Slide 7 公式)
    s_theoretical = 1 / np.sqrt(pi)
    
    # 2. 遍历搜索实际最优整数 s
    best_s = 1
    min_e = N
    for s in range(1, int(s_theoretical) + 10):
        e = group_testing_expectation(pi, s, N)
        if e < min_e:
            min_e = e
            best_s = s
    
    print(f"\n--- 最优决策结论 ---")
    print(f"当阳性率 pi = {pi:.2%} 时:")
    print(f"理论建议组大小 s ≈ {s_theoretical:.2f}")
    print(f"实际最优组大小 s = {best_s}")
    print(f"最省检测次数 E[X] ≈ {min_e:.2f}")
    return best_s

# ==========================================
# 考试快速调用示例 (按讲义参数)
# ==========================================
if __name__ == "__main__":
    # 1. 新冠检测悖论 (Slide 4)
    # 灵敏度 99%, 特异性 95%, 患病率 0.1%
    bayes_posterior(sensitivity=0.99, specificity=0.95, prevalence=0.001)
    
    print("\n" + "="*40 + "\n")
    
    # 2. 混采检测决策 (Slide 5-7)
    # 假设阳性率 1%, 总人数 1000
    find_optimal_group_size(pi=0.01, N=1000)
