# -*- coding: utf-8 -*-
"""
生物医学统计 - 假设检验与 ANOVA (Slide 18-27 专用模板)
涵盖：Student/Welch T-test, ANOVA 前提检查, 回归视角与哑变量, 事后检验
"""

import pandas as pd
import numpy as np
from scipy import stats
import statsmodels.api as sm
from statsmodels.formula.api import ols
from statsmodels.stats.multicomp import pairwise_tukeyhsd

# ==========================================
# 1. T 检验模块 (Slide 18-22)
# ==========================================
def run_smart_ttest(g1, g2):
    """
    自动判断使用 Student's 还是 Welch's T-test
    """
    # 1. 方差齐性检验 (Levene's Test)
    stat, p_levene = stats.levene(g1, g2)
    
    # 2. 执行检验
    # 如果 p_levene < 0.05，认为方差不齐，使用 Welch's (equal_var=False)
    is_equal_var = p_levene > 0.05
    t_stat, p_val = stats.ttest_ind(g1, g2, equal_var=is_equal_var)
    
    print(f"--- T 检验分析 ---")
    print(f"Levene 方差齐性 P 值: {p_levene:.4f}")
    print(f"结论: {'方差齐, 使用 Student T' if is_equal_var else '方差不齐, 使用 Welch T'}")
    print(f"T 统计量: {t_stat:.4f}, P 值: {p_val:.4f}")
    print(f"显著性 (alpha=0.05): {'显著差异 (拒绝H0)' if p_val < 0.05 else '无显著差异 (接受H0)'}")
    return t_stat, p_val

# ==========================================
# 2. ANOVA 前提检查 (Slide 24)
# ==========================================
def check_anova_assumptions(df, value_col, group_col):
    """
    检查正态性 (Shapiro-Wilk) 和方差齐性 (Levene)
    """
    groups = [df[df[group_col] == g][value_col] for g in df[group_col].unique()]
    
    # 1. 正态性检查
    print("--- 正态性检查 (Shapiro-Wilk) ---")
    all_normal = True
    for i, g_data in enumerate(groups):
        _, p_sw = stats.shapiro(g_data)
        print(f"组 {df[group_col].unique()[i]} P 值: {p_sw:.4f}")
        if p_sw < 0.05: all_normal = False
    
    # 2. 方差齐性
    _, p_levene = stats.levene(*groups)
    print(f"\n--- 方差齐性检查 (Levene) ---")
    print(f"P 值: {p_levene:.4f}")
    
    return all_normal, p_levene > 0.05

# ==========================================
# 3. ANOVA 与 回归视角 (Slide 23, 25-27)
# ==========================================
def run_complete_anova(df, value_col, group_col):
    """
    执行 ANOVA, 输出回归摘要(含哑变量)和事后检验
    """
    # 1. 前提检查
    is_norm, is_homo = check_anova_assumptions(df, value_col, group_col)
    if not (is_norm and is_homo):
        print("\n警告: 数据不完全满足 ANOVA 前提条件，结果仅供参考！")
    
    # 2. 线性模型视角 (OLS + 哑变量)
    formula = f"{value_col} ~ C({group_col})"
    model = ols(formula, data=df).fit()
    anova_table = sm.stats.anova_lm(model, typ=2)
    
    print(f"\n--- ANOVA 表 (F-检验) ---")
    print(anova_table)
    
    print(f"\n--- 回归视角 (哑变量系数) ---")
    # 这里的系数表示相对于基准组 (Reference Group) 的差异
    print(model.summary().tables[1])
    
    # 3. 事后检验 (Tukey HSD) - 只有 ANOVA 显著才看这个
    if anova_table['PR(>F)'][0] < 0.05:
        print(f"\n--- 事后检验 (Tukey HSD) ---")
        tukey = pairwise_tukeyhsd(endog=df[value_col], groups=df[group_col], alpha=0.05)
        print(tukey)
    
    return model, anova_table

# ==========================================
# 考场快速调用示例
# ==========================================
if __name__ == "__main__":
    # 1. T 检验示例
    group_a = [85, 88, 90, 92, 95]
    group_b = [70, 80, 85, 88, 90]
    run_smart_ttest(group_a, group_b)
    
    print("\n" + "="*50 + "\n")
    
    # 2. ANOVA 示例 (4组药物)
    data = {
        'Score': [10, 12, 11, 13, 20, 22, 21, 23, 30, 32, 31, 33, 15, 16, 14, 17],
        'Drug': ['Placebo']*4 + ['DrugA']*4 + ['DrugB']*4 + ['DrugC']*4
    }
    df_drug = pd.DataFrame(data)
    run_complete_anova(df_drug, 'Score', 'Drug')
