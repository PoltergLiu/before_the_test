# -*- coding: utf-8 -*-
"""
生物医学统计 - 模型检验与分布拟合 (Slide 28-32 专用模板)
涵盖：超离散检测、Chi2 拟合优度检验、RNA-seq 分布选择 (Poisson vs NB)
"""

import numpy as np
import pandas as pd
from scipy import stats

# ==========================================
# 1. 超离散 (Overdispersion) 检测器
# ==========================================
def check_overdispersion(data, dist_type='poisson'):
    """
    检查数据是否存在超离散现象
    - Poisson: 均值应该等于方差 (Var/Mean ≈ 1)
    - Binomial: 方差应该等于 n*p*(1-p)
    """
    mean_val = np.mean(data)
    var_val = np.var(data, ddof=1)
    ratio = var_val / mean_val
    
    print(f"--- 超离散检测 ({dist_type}) ---")
    print(f"样本均值: {mean_val:.4f}")
    print(f"样本方差: {var_val:.4f}")
    print(f"方差/均值比 (Dispersion Ratio): {ratio:.4f}")
    
    if dist_type == 'poisson':
        if ratio > 1.2:
            print("结论: 存在明显的超离散 (方差 > 均值)，建议使用负二项分布 (NB)。")
        else:
            print("结论: 符合泊松分布假设。")
    return ratio

# ==========================================
# 2. 拟合优度检验 (Goodness of Fit) (Slide 31-32)
# ==========================================
def chi_square_goodness_of_fit(observed_counts, expected_probs):
    """
    执行卡方拟合优度检验
    参数:
    - observed_counts: 实际观测到的各频次 (e.g., [1, 5, 10, ...])
    - expected_probs: 模型预测的各频次对应的概率
    """
    total_n = np.sum(observed_counts)
    expected_counts = expected_probs * total_n
    
    # 卡方检验要求期望频数尽量大于 5，这里简单处理
    chi2_stat, p_val = stats.chisquare(f_obs=observed_counts, f_exp=expected_counts)
    
    print(f"--- 卡方拟合优度检验 ---")
    print(f"Chi2 统计量: {chi2_stat:.4f}")
    print(f"P 值: {p_val:.4f}")
    
    # 注意：拟合优度检验中，P > 0.05 代表拟合良好（没有显著差异）
    if p_val > 0.05:
        print("结论: 接受 H0，模型拟合良好 (P > 0.05)。")
    else:
        print("结论: 拒绝 H0，模型与实际数据存在显著差异 (P < 0.05)。")
    return p_val

# ==========================================
# 3. 针对作业四：RNA-seq 分布分析逻辑
# ==========================================
def analyze_rnaseq_distribution(gene_counts):
    """
    自动分析 RNA-seq 表达量数据应选择哪种分布
    """
    print(">>> 步骤 1: 检查均值与方差关系")
    ratio = check_overdispersion(gene_counts, dist_type='poisson')
    
    print("\n>>> 步骤 2: 拟合优度模拟对比 (示意)")
    # 拟合泊松分布参数
    mu = np.mean(gene_counts)
    # 计算泊松分布下的理论概率
    max_val = int(np.max(gene_counts))
    observed_freq = np.bincount(gene_counts)
    # 补齐长度
    expected_probs = stats.poisson.pmf(np.arange(len(observed_freq)), mu)
    # 归一化概率
    expected_probs = expected_probs / np.sum(expected_probs)
    
    chi_square_goodness_of_fit(observed_freq, expected_probs)

# ==========================================
# 考场快速调用示例 (模拟讲义 Slide 28-32)
# ==========================================
if __name__ == "__main__":
    # 1. 模拟讲义中的“男孩出生案例”
    # 假设 12 个孩子的家庭中，男孩数量的分布 (13个分类: 0-12个)
    # 观测到的家庭数量 (Observed)
    obs_counts = np.array([3, 24, 104, 286, 670, 1033, 1343, 1112, 829, 478, 181, 45, 7])
    n_kids = 12
    
    print(">>> 场景 A: 检验简单二项分布 Binomial(12, 0.5192)")
    p_hat = 0.5192
    expected_probs_bin = stats.binom.pmf(np.arange(13), n_kids, p_hat)
    chi_square_goodness_of_fit(obs_counts, expected_probs_bin)
    
    print("\n" + "="*40 + "\n")
    
    print(">>> 场景 B: 针对作业四的 RNA-seq 数据")
    # 假设某基因在 6 个样本中的表达量
    liver_data = [120, 150, 400, 80, 210, 350] 
    analyze_rnaseq_distribution(liver_data)
