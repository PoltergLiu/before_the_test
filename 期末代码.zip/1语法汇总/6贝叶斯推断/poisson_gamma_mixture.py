# -*- coding: utf-8 -*-
"""
生物医学统计 - Poisson-Gamma 复合模型 (混合分布)
原理：
  1. 假设每个个体的泊松参数 λ_i 不尽相同，且服从 Gamma(alpha, beta) 分布。
  2. 观测值 X_i | λ_i ~ Poisson(λ_i)。
  3. X_i 的边缘分布 (Marginal Distribution) 即为负二项分布 Negative Binomial。
"""

import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import gamma, poisson, nbinom

# 设置中文显示
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False

def simulate_poisson_gamma_mixture(alpha, beta_rate, n_samples=5000):
    """
    模拟 Poisson-Gamma 混合过程并验证其与负二项分布的一致性
    :param alpha: Gamma 分布的形状参数 (shape)
    :param beta_rate: Gamma 分布的速率参数 (rate, 1/scale)
    """
    # 1. 从 Gamma 分布中抽取 λ
    # Scipy 使用 scale = 1/rate
    lambdas = gamma.rvs(alpha, scale=1/beta_rate, size=n_samples)
    
    # 2. 对于每个 λ，抽取一个泊松观测值
    counts = poisson.rvs(lambdas)
    
    # 3. 计算理论负二项分布参数 (n, p)
    # 对应关系：n = alpha, p = beta / (1 + beta)
    n_nb = alpha
    p_nb = beta_rate / (1 + beta_rate)
    
    print(f"--- Poisson-Gamma Mixture Simulation ---")
    print(f"Gamma Params: alpha={alpha}, beta={beta_rate}")
    print(f"Theoretical Mean: {alpha/beta_rate:.4f}")
    print(f"Sample Mean: {np.mean(counts):.4f}")
    print(f"Theoretical Variance: {alpha/beta_rate * (1 + 1/beta_rate):.4f}")
    print(f"Sample Variance: {np.var(counts):.4f}")
    
    # 4. 可视化对比
    plt.figure(figsize=(10, 6))
    
    # 绘制模拟数据的直方图
    max_val = int(np.percentile(counts, 99))
    bins = np.arange(0, max_val + 2) - 0.5
    plt.hist(counts, bins=bins, density=True, alpha=0.5, label='Simulated (Poisson-Gamma)', color='skyblue', edgecolor='black')
    
    # 绘制理论负二项分布 PMF
    x = np.arange(0, max_val + 1)
    plt.step(x, nbinom.pmf(x, n_nb, p_nb), where='mid', color='red', lw=2, label=f'Theoretical NB(n={n_nb:.1f}, p={p_nb:.2f})')
    
    plt.title('Poisson-Gamma 复合模型模拟 vs 理论负二项分布')
    plt.xlabel('观测值 (Count)')
    plt.ylabel('概率密度')
    plt.legend()
    plt.grid(axis='y', alpha=0.3)
    plt.show()

# ==========================================
# 考试调用指南
# ==========================================
if __name__ == "__main__":
    # 场景：如果题目提到“泊松参数服从 Gamma 分布”，问你最终分布是什么
    # 或者让你模拟这种过程。
    ALPHA = 5.0    # 形状
    BETA_RATE = 2.0 # 速率
    
    simulate_poisson_gamma_mixture(ALPHA, BETA_RATE)
