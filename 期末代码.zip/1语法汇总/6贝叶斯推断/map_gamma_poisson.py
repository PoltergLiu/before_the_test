# -*- coding: utf-8 -*-
"""
生物医学统计 - MAP 估计 (Gamma-Poisson)
模型：
  - 先验分布 (Prior): Gamma(shape=alpha, rate=beta)  # 注意：Scipy 使用的是 scale = 1/beta
  - 似然函数 (Likelihood): Poisson(lambda)
  - 后验分布 (Posterior): Gamma(alpha + sum(x_i), beta + n)
"""

import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import gamma, poisson

# 设置中文显示
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False

def analyze_gamma_poisson(alpha_prior, beta_prior, data):
    """
    进行 Gamma-Poisson MAP 分析
    :param alpha_prior: 先验 Gamma 的形状参数 (shape)
    :param beta_prior: 先验 Gamma 的速率参数 (rate, 1/scale)
    :param data: 观测到的样本数据 (list 或 array)
    """
    n = len(data)
    sum_x = np.sum(data)
    
    # 1. 计算后验参数
    alpha_post = alpha_prior + sum_x
    beta_post = beta_prior + n
    
    # 2. 计算估计值
    mle_lambda = np.mean(data)
    # Gamma 分布的众数 (MAP): (alpha - 1) / beta
    if alpha_post >= 1:
        map_lambda = (alpha_post - 1) / beta_post
    else:
        map_lambda = 0
        
    print(f"--- Gamma-Poisson Inference ---")
    print(f"Prior: Gamma(shape={alpha_prior}, rate={beta_prior})")
    print(f"Data: n={n} samples, sum(x)={sum_x}")
    print(f"Posterior: Gamma(shape={alpha_post}, rate={beta_post})")
    print(f"MLE Estimate (λ): {mle_lambda:.4f}")
    print(f"MAP Estimate (λ): {map_lambda:.4f}")
    
    # 3. 可视化
    # 注意 Scipy 的 gamma.pdf(x, a, scale=1/beta)
    x = np.linspace(0, max(mle_lambda, map_lambda)*3 + 2, 500)
    plt.figure(figsize=(12, 7))
    
    # 绘制先验
    plt.plot(x, gamma.pdf(x, alpha_prior, scale=1/beta_prior), 'g--', label=f'Prior Gamma(α={alpha_prior}, β={beta_prior})')
    # 绘制后验
    plt.plot(x, gamma.pdf(x, alpha_post, scale=1/beta_post), 'r-', lw=2, label=f'Posterior Gamma(α={alpha_post}, β={beta_post})')
    
    plt.axvline(map_lambda, color='r', linestyle='-.', label=f'MAP λ = {map_lambda:.4f}')
    plt.axvline(mle_lambda, color='b', linestyle='-.', label=f'MLE λ = {mle_lambda:.4f}')
    
    plt.title('Gamma-Poisson 贝叶斯推断 (Prior vs Posterior)')
    plt.xlabel('参数 λ')
    plt.ylabel('密度')
    plt.legend()
    plt.grid(True, alpha=0.3)
    plt.show()

# ==========================================
# 考试调用指南
# ==========================================
if __name__ == "__main__":
    # 场景：罕见病发病率、放射性粒子计数
    # 假设先验：对 λ 有一定预期，均值为 alpha/beta
    ALPHA_PRIOR = 2  # shape
    BETA_PRIOR = 1   # rate
    
    # 观测数据：一周内每天的病例数
    OBS_DATA = [3, 2, 4, 1, 2] # 样本均值 2.4
    
    analyze_gamma_poisson(ALPHA_PRIOR, BETA_PRIOR, OBS_DATA)
