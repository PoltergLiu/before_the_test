# -*- coding: utf-8 -*-
"""
生物医学统计 - MAP 估计 (Beta-Binomial)
模型：
  - 先验分布 (Prior): Beta(alpha, beta)
  - 似然函数 (Likelihood): Binomial(n, k)
  - 后验分布 (Posterior): Beta(alpha + k, beta + n - k)
"""

import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import beta, binom

# 设置中文显示
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False

def analyze_beta_binomial(alpha_prior, beta_prior, n_trials, k_successes):
    """
    进行 Beta-Binomial MAP 分析
    """
    # 1. 计算后验参数
    alpha_post = alpha_prior + k_successes
    beta_post = beta_prior + n_trials - k_successes
    
    # 2. 计算估计值
    mle_p = k_successes / n_trials
    # Beta 分布的众数 (MAP): (alpha - 1) / (alpha + beta - 2)
    if alpha_post > 1 and beta_post > 1:
        map_p = (alpha_post - 1) / (alpha_post + beta_post - 2)
    else:
        map_p = None # 边界情况
        
    print(f"--- Beta-Binomial Inference ---")
    print(f"Prior: Beta(α={alpha_prior}, β={beta_prior})")
    print(f"Data: n={n_trials}, k={k_successes}")
    print(f"Posterior: Beta(α={alpha_post}, β={beta_post})")
    print(f"MLE Estimate: {mle_p:.4f}")
    if map_p is not None:
        print(f"MAP Estimate: {map_p:.4f}")
    
    # 3. 可视化
    x = np.linspace(0, 1, 500)
    plt.figure(figsize=(12, 7))
    
    # 绘制先验
    plt.plot(x, beta.pdf(x, alpha_prior, beta_prior), 'g--', label=f'Prior Beta({alpha_prior}, {beta_prior})')
    # 绘制似然 (为了在同一图中显示，进行了缩放)
    likelihood = binom.pmf(k_successes, n_trials, x)
    plt.plot(x, likelihood / np.max(likelihood) * np.max(beta.pdf(x, alpha_post, beta_post)), 'y:', label='Likelihood (Scaled)')
    # 绘制后验
    plt.plot(x, beta.pdf(x, alpha_post, beta_post), 'r-', lw=2, label=f'Posterior Beta({alpha_post}, {beta_post})')
    
    if map_p:
        plt.axvline(map_p, color='r', linestyle='-.', label=f'MAP = {map_p:.4f}')
    plt.axvline(mle_p, color='b', linestyle='-.', label=f'MLE = {mle_p:.4f}')
    
    plt.title('Beta-Binomial 贝叶斯推断 (Prior vs Posterior)')
    plt.xlabel('参数 p')
    plt.ylabel('密度')
    plt.legend()
    plt.grid(True, alpha=0.3)
    plt.show()

# ==========================================
# 考试调用指南
# ==========================================
if __name__ == "__main__":
    # 场景：硬币投掷或药物有效率
    # 假设先验：对 p 比较均匀 (1, 1) 或 有一定倾向 (如 2, 5)
    ALPHA_PRIOR = 2
    BETA_PRIOR = 2
    
    # 观测数据：试验 10 次，成功 8 次
    N = 10
    K = 8
    
    analyze_beta_binomial(ALPHA_PRIOR, BETA_PRIOR, N, K)
