# -*- coding: utf-8 -*-
"""
生物医学统计 - 极大似然估计 (MLE) 分析脚本
功能：实现常用分布（正态、二项、泊松）的 MLE 参数估计及可视化
"""

import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import minimize
from scipy.stats import norm, binom, poisson

# 设置中文显示
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False

def mle_normal(data):
    """正态分布的 MLE 估计"""
    mu_mle = np.mean(data)
    sigma_mle = np.std(data)  # MLE 估计量是除以 n 而非 n-1
    return mu_mle, sigma_mle

def mle_binomial(n, k):
    """二项分布的 MLE 估计 (n 次试验, k 次成功)"""
    p_mle = k / n
    return p_mle

def mle_poisson(data):
    """泊松分布的 MLE 估计"""
    lambda_mle = np.mean(data)
    return lambda_mle

def plot_likelihood(data, dist_type='normal'):
    """绘制似然函数曲线"""
    plt.figure(figsize=(10, 6))
    
    if dist_type == 'normal':
        mu_range = np.linspace(np.mean(data)-1, np.mean(data)+1, 100)
        # 固定 sigma, 观察 mu 的似然
        sigma_fixed = np.std(data)
        likelihoods = [np.prod(norm.pdf(data, loc=m, scale=sigma_fixed)) for m in mu_range]
        plt.plot(mu_range, likelihoods, label='Likelihood L(μ)')
        plt.axvline(np.mean(data), color='r', linestyle='--', label=f'MLE μ = {np.mean(data):.4f}')
        plt.xlabel('参数 μ')
        
    elif dist_type == 'binomial':
        # 假设输入 data 为 (n, k)
        n, k = data
        p_range = np.linspace(0, 1, 100)
        likelihoods = [binom.pmf(k, n, p) for p in p_range]
        plt.plot(p_range, likelihoods, label='Likelihood L(p)')
        plt.axvline(k/n, color='r', linestyle='--', label=f'MLE p = {k/n:.4f}')
        plt.xlabel('参数 p')
        
    plt.title(f'{dist_type.capitalize()} 分布的似然函数')
    plt.ylabel('似然值')
    plt.legend()
    plt.grid(True, alpha=0.3)
    plt.show()

# ==========================================
# 考试调用指南
# ==========================================
if __name__ == "__main__":
    # 示例 1: 正态分布数据
    sample_data = np.random.normal(loc=5.0, scale=1.5, size=100)
    mu, sigma = mle_normal(sample_data)
    print(f"--- Normal MLE ---")
    print(f"Estimated mu: {mu:.4f}, sigma: {sigma:.4f}")
    # plot_likelihood(sample_data, 'normal')

    # 示例 2: 二项分布 (试验10次, 成功7次)
    n_trial, k_success = 10, 7
    p_hat = mle_binomial(n_trial, k_success)
    print(f"\n--- Binomial MLE ---")
    print(f"Estimated p: {p_hat:.4f}")
    # plot_likelihood((n_trial, k_success), 'binomial')
    
    # 示例 3: 泊松分布
    poi_data = [2, 3, 1, 4, 2, 5, 2]
    lam_hat = mle_poisson(poi_data)
    print(f"\n--- Poisson MLE ---")
    print(f"Estimated lambda: {lam_hat:.4f}")
