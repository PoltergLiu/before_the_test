# -*- coding: utf-8 -*-
"""
生物医学统计 - 负二项分布 (Negative Binomial) 分析
功能：参数估计、过度离散 (Overdispersion) 检验、与泊松分布对比
应用场景：当计数数据的方差远大于均值时，泊松回归失效，应改用负二项模型。
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.stats import nbinom, poisson
from scipy.optimize import minimize

# 设置中文显示
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False

def fit_negative_binomial(data):
    """
    对数据进行负二项分布的极大似然估计 (MLE)
    """
    # 初始猜测：根据均值和方差计算矩估计
    mu = np.mean(data)
    var = np.var(data)
    if var <= mu:
        print("警告：方差不大于均值，负二项分布可能不适用（无过度离散）。")
        # 强制给一个初始值
        r_init = 100
    else:
        r_init = (mu**2) / (var - mu)
    
    p_init = r_init / (r_init + mu)

    # 定义负对数似然函数
    def neg_log_likelihood(params):
        r, p = params
        if r <= 0 or p <= 0 or p >= 1:
            return 1e10
        return -np.sum(nbinom.logpmf(data, r, p))

    res = minimize(neg_log_likelihood, [r_init, p_init], bounds=[(1e-5, None), (1e-5, 0.9999)])
    return res.x # 返回 [r, p]

def check_overdispersion(data):
    """
    简易过度离散检验
    """
    mu = np.mean(data)
    var = np.var(data)
    ratio = var / mu
    print(f"--- Overdispersion Check ---")
    print(f"Mean: {mu:.4f}")
    print(f"Variance: {var:.4f}")
    print(f"Variance/Mean Ratio: {ratio:.4f}")
    if ratio > 1.2:
        print("结论：存在明显的过度离散 (Ratio > 1.2)，建议使用负二项分布。")
    else:
        print("结论：过度离散不明显，泊松分布可能足够。")

def compare_models(data):
    """
    对比泊松分布与负二项分布的拟合效果
    """
    mu_poi = np.mean(data)
    r_nb, p_nb = fit_negative_binomial(data)
    
    plt.figure(figsize=(10, 6))
    max_val = int(np.max(data))
    x = np.arange(0, max_val + 1)
    
    # 原始数据
    bins = np.arange(0, max_val + 2) - 0.5
    plt.hist(data, bins=bins, density=True, alpha=0.3, label='Observed Data', color='gray')
    
    # 泊松拟合
    plt.plot(x, poisson.pmf(x, mu_poi), 'bo-', label=f'Poisson (λ={mu_poi:.2f})')
    
    # 负二项拟合
    plt.plot(x, nbinom.pmf(x, r_nb, p_nb), 'rs-', label=f'Neg-Binom (r={r_nb:.2f}, p={p_nb:.2f})')
    
    plt.title('模型对比：泊松 vs 负二项')
    plt.xlabel('Count')
    plt.ylabel('Probability')
    plt.legend()
    plt.grid(True, alpha=0.3)
    plt.show()

# ==========================================
# 考试调用指南
# ==========================================
if __name__ == "__main__":
    # 模拟一份具有过度离散的数据
    # 比如：均值为 10，但方差很大的计数数据
    np.random.seed(42)
    # 使用 n=5, p=0.3 的负二项分布生成数据
    # 均值 = r(1-p)/p = 5*0.7/0.3 = 11.6
    # 方差 = r(1-p)/p^2 = 5*0.7/0.09 = 38.8
    test_data = nbinom.rvs(n=5, p=0.3, size=200)
    
    check_overdispersion(test_data)
    compare_models(test_data)
    
    r_mle, p_mle = fit_negative_binomial(test_data)
    print(f"\nMLE Results for Negative Binomial:")
    print(f"Estimated r (Dispersion): {r_mle:.4f}")
    print(f"Estimated p: {p_mle:.4f}")
    print(f"Implied Mean: {r_mle*(1-p_mle)/p_mle:.4f}")
