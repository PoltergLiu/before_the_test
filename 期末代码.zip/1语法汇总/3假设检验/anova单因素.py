import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats
import statsmodels.api as sm
from statsmodels.formula.api import ols
from statsmodels.stats.multicomp import pairwise_tukeyhsd

# =================================================================
# 单因素方差分析 (One-way ANOVA) 完整实战流程
# =================================================================

def complete_oneway_anova_flow(df, value_col, group_col):
    """
    输入: 
    - df: 包含数据的 DataFrame
    - value_col: 连续变量列名 (如 'blood_pressure')
    - group_col: 分类变量列名 (如 'drug_group')
    """
    print(f"{'='*20} 1. 描述性统计 {'='*20}")
    desc_stats = df.groupby(group_col)[value_col].agg(['count', 'mean', 'std', 'median'])
    print(desc_stats)
    print("\n")

    print(f"{'='*20} 2. 前提假设检验 {'='*20}")
    # 2.1 正态性检验 (Shapiro-Wilk) - 每组都需要符合正态分布
    print("正态性检验 (Shapiro-Wilk):")
    is_normal = True
    for name, group in df.groupby(group_col):
        stat, p = stats.shapiro(group[value_col])
        print(f"  - 组别 {name}: p-value = {p:.4f} {'(符合正态)' if p > 0.05 else '(不符合正态!!!)'}")
        if p <= 0.05: is_normal = False
    
    # 2.2 方差齐性检验 (Levene Test)
    groups = [group[value_col].values for name, group in df.groupby(group_col)]
    stat_l, p_l = stats.levene(*groups)
    print(f"\n方差齐性检验 (Levene): p-value = {p_l:.4f} {'(方差齐)' if p_l > 0.05 else '(方差不齐!!!)'}")
    print("\n")

    print(f"{'='*20} 3. ANOVA 计算 {'='*20}")
    # 构建模型
    formula = f'{value_col} ~ C({group_col})'
    model = ols(formula, data=df).fit()
    anova_table = sm.stats.anova_lm(model, typ=2)
    print(anova_table)
    
    p_anova = anova_table['PR(>F)'][0]
    print(f"\nANOVA 结论: p = {p_anova:.4f}")
    if p_anova < 0.05:
        print(">>> 拒绝原假设，各组均值之间存在显著差异。")
    else:
        print(">>> 接受原假设，各组均值之间无显著差异。")
    print("\n")

    # 4. 事后检验 (如果 ANOVA 显著)
    if p_anova < 0.05:
        print(f"{'='*20} 4. 事后检验 (Tukey HSD) {'='*20}")
        tukey = pairwise_tukeyhsd(endog=df[value_col], groups=df[group_col], alpha=0.05)
        print(tukey)
        
        # 绘制事后检验置信区间图
        tukey.plot_simultaneous()
        plt.title("Tukey HSD Comparison")
        plt.show()

    # 5. 可视化
    print(f"{'='*20} 5. 数据可视化 {'='*20}")
    plt.figure(figsize=(10, 6))
    sns.boxplot(x=group_col, y=value_col, data=df, palette="Set3")
    sns.swarmplot(x=group_col, y=value_col, data=df, color=".25", alpha=0.5) # 叠加散点看分布
    plt.title(f"Boxplot of {value_col} by {group_col}")
    plt.show()

# ==========================================
# 考场调参指南 (EXAM QUICK START)
# ==========================================
"""
1. 读取数据: 
   df = pd.read_excel("你的文件名.xlsx")

2. 运行函数: 
   complete_oneway_anova_flow(df, value_col='你的数值列名', group_col='你的分组列名')

3. 结果解读:
   - Step 2: 如果 Levene Test p < 0.05 (方差不齐)，ANOVA 结论需谨慎，建议查看非参数检验。
   - Step 3: 关注 PR(>F) 这一列，即为 P 值。
   - Step 4: 事后检验 (Tukey HSD) 中 reject 为 True 的行，表示那两组之间有显著差异。
"""
