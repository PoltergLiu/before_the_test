import numpy as np
from scipy import stats

# =================================================================
# 1. 分布临界值与 P 值计算 (基础模块)
# 场景: 老师给出统计量(Z, T, F, Chi2)，让你查表或判断是否拒绝原假设
# =================================================================

def get_z_info(z_stat, alpha=0.05, alternative='two-sided'):
    """正态分布 (Z)"""
    if alternative == 'two-sided':
        p_val = 2 * (1 - stats.norm.cdf(abs(z_stat)))
        crit_val = stats.norm.ppf(1 - alpha/2)
    else:
        p_val = 1 - stats.norm.cdf(z_stat)
        crit_val = stats.norm.ppf(1 - alpha)
    print(f"Z-Test: P-value = {p_val:.4f}, Critical Value = {crit_val:.4f}")
    return p_val, crit_val

def get_t_info(t_stat, df, alpha=0.05, alternative='two-sided'):
    """T 分布 (需要自由度 df)"""
    if alternative == 'two-sided':
        p_val = 2 * (1 - stats.t.cdf(abs(t_stat), df))
        crit_val = stats.t.ppf(1 - alpha/2, df)
    else:
        p_val = 1 - stats.t.cdf(t_stat, df)
        crit_val = stats.t.ppf(1 - alpha, df)
    print(f"T-Test (df={df}): P-value = {p_val:.4f}, Critical Value = {crit_val:.4f}")
    return p_val, crit_val

def get_f_info(f_stat, dfn, dfd, alpha=0.05):
    """F 分布 (方差分析，通常为单侧)"""
    p_val = 1 - stats.f.cdf(f_stat, dfn, dfd)
    crit_val = stats.f.ppf(1 - alpha, dfn, dfd)
    print(f"F-Test (dfn={dfn}, dfd={dfd}): P-value = {p_val:.4f}, Critical Value = {crit_val:.4f}")
    return p_val, crit_val

def get_chi2_info(chi_stat, df, alpha=0.05):
    """卡方分布 (分类数据)"""
    p_val = 1 - stats.chi2.cdf(chi_stat, df)
    crit_val = stats.chi2.ppf(1 - alpha, df)
    print(f"Chi2-Test (df={df}): P-value = {p_val:.4f}, Critical Value = {crit_val:.4f}")
    return p_val, crit_val


# =================================================================
# 2. 常用假设检验 (实战模块)
# =================================================================

# --- 2.1 T 检验 ---
def run_t_tests(g1, g2=None, mu=0, paired=False):
    """
    1. 单样本 T 检验 (g1 vs mu)
    2. 独立样本 T 检验 (g1 vs g2)
    3. 配对样本 T 检验 (paired=True)
    """
    if g2 is None:
        # 单样本
        stat, p = stats.ttest_1samp(g1, mu)
        print(f"One-sample T-test: t={stat:.3f}, p={p:.4f}")
    elif paired:
        # 配对样本
        stat, p = stats.ttest_rel(g1, g2)
        print(f"Paired T-test: t={stat:.3f}, p={p:.4f}")
    else:
        # 独立样本 (Welch's T-test, 不假设方差齐性)
        stat, p = stats.ttest_ind(g1, g2, equal_var=False)
        print(f"Independent T-test: t={stat:.3f}, p={p:.4f}")
    return stat, p

# --- 2.2 方差齐性检验 (Levene Test) ---
# 场景: 在做 ANOVA 或 T 检验前，检查各组方差是否相等
def check_variance_homogeneity(*groups):
    stat, p = stats.levene(*groups)
    print(f"Levene Test (Variance): p={p:.4f} ({'齐性' if p>0.05 else '不齐'})")
    return p > 0.05

# --- 2.3 ANOVA (单因素方差分析) ---
def run_anova(*groups):
    stat, p = stats.f_oneway(*groups)
    print(f"One-way ANOVA: F={stat:.3f}, p={p:.4f}")
    return stat, p

# --- 2.4 非参数检验 (数据不符合正态分布时使用) ---
def run_nonparametric(g1, g2):
    """曼-惠特尼 U 检验 (代替独立样本 T 检验)"""
    stat, p = stats.mannwhitneyu(g1, g2)
    print(f"Mann-Whitney U test: p={p:.4f}")
    return p


# =================================================================
# 3. 关联性分析 (分类变量)
# =================================================================

def run_chi2_contingency(df, col1, col2):
    """
    卡方检验 (Chi-square)
    场景: 检查 性别(男/女) 与 患病(是/否) 是否有关
    """
    table = pd.crosstab(df[col1], df[col2])
    chi2, p, dof, expected = stats.chi2_contingency(table)
    print(f"Chi-square: {chi2:.3f}, p={p:.4f}, df={dof}")
    
    # 如果是 2x2 表格且样本量小，建议看 Fisher 精确检验
    if table.shape == (2, 2):
        oddsratio, p_fisher = stats.fisher_exact(table)
        print(f"Fisher's Exact Test: p={p_fisher:.4f}")
        
    return p

# ==========================================
# 考场调参指南 (EXAM QUICK START)
# ==========================================
"""
1. 查表计算临界值:
   - 调用 get_t_info(t_stat=2.5, df=30): 填入你的 t 值和自由度。
   - 调用 get_f_info(f_stat=4.0, dfn=2, dfd=27): 填入 F 值和两个自由度。

2. 独立样本 T 检验 (最常用):
   - g1 = [数据1...], g2 = [数据2...]
   - run_t_tests(g1, g2, paired=False)
   - 注意：脚本默认使用 equal_var=False (Welch T检验)，考场最稳。

3. 配对 T 检验 (前后对比):
   - run_t_tests(before_data, after_data, paired=True)

4. 单因素 ANOVA:
   - run_anova(group1, group2, group3)

5. 卡方检验 (关联性):
   - 准备 DataFrame，填入 run_chi2_contingency(df, '性别', '患病') 对应的列名。
"""
