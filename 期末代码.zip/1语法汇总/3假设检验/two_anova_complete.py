import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats
import statsmodels.api as sm
from statsmodels.formula.api import ols
from statsmodels.stats.multicomp import pairwise_tukeyhsd
from statsmodels.graphics.factorplots import interaction_plot

# =================================================================
# 双因素方差分析 (Two-way ANOVA) 完整实战流程
# =================================================================

def complete_twoway_anova_flow(df, value_col, factor1, factor2):
    """
    输入:
    - df: DataFrame
    - value_col: 数值列 (如 'Effect')
    - factor1: 第一个分类变量 (如 'Drug')
    - factor2: 第二个分类变量 (如 'Gender')
    """
    print(f"{'='*20} 1. 分层描述性统计 {'='*20}")
    desc = df.groupby([factor1, factor2])[value_col].agg(['count', 'mean', 'std']).reset_index()
    print(desc)
    print("\n")

    print(f"{'='*20} 2. 构建模型与 ANOVA 计算 {'='*20}")
    # 建立线性模型，包含交互项 (factor1*factor2)
    # C() 表示强制设为分类变量
    formula = f'{value_col} ~ C({factor1}) + C({factor2}) + C({factor1}):C({factor2})'
    model = ols(formula, data=df).fit()
    
    # 执行 ANOVA (使用 Type II SS，更适合生物医学实验)
    anova_table = sm.stats.anova_lm(model, typ=2)
    print(anova_table)
    print("\n")

    # 提取 P 值
    p_f1 = anova_table.loc[f'C({factor1})', 'PR(>F)']
    p_f2 = anova_table.loc[f'C({factor2})', 'PR(>F)']
    p_inter = anova_table.loc[f'C({factor1}):C({factor2})', 'PR(>F)']

    print(f"{'='*20} 3. 结果解读 {'='*20}")
    print(f"- {factor1} 主效应: {'显著 (p<0.05)' if p_f1 < 0.05 else '不显著'}")
    print(f"- {factor2} 主效应: {'显著 (p<0.05)' if p_f2 < 0.05 else '不显著'}")
    print(f"- 交互作用 ({factor1}*{factor2}): {'显著 (p<0.05)' if p_inter < 0.05 else '不显著'}")
    print("\n")

    print(f"{'='*20} 4. 可视化 (交互作用图) {'='*20}")
    # 交互作用图是双因素 ANOVA 的灵魂
    plt.figure(figsize=(10, 6))
    fig = interaction_plot(x=df[factor1], trace=df[factor2], response=df[value_col],
                          colors=['red', 'blue', 'green'], markers=['D', '^', 'o'],
                          ms=10, ax=plt.gca())
    plt.title(f"Interaction Plot: {factor1} & {factor2}")
    plt.show()

    # 5. 事后检验 (如果交互作用显著)
    if p_inter < 0.05:
        print(f"{'='*20} 5. 事后检验 (Tukey HSD) {'='*20}")
        print("注意: 交互作用显著时，通常需要分析 '组合条件' 下的差异。")
        # 创建一个组合列用于事后比较
        df['combined'] = df[factor1].astype(str) + "_" + df[factor2].astype(str)
        tukey = pairwise_tukeyhsd(endog=df[value_col], groups=df['combined'], alpha=0.05)
        print(tukey.summary())
    
    # 6. 前提检查 (残差正态性)
    print(f"\n{'='*20} 6. 模型前提检查 {'='*20}")
    res = model.resid
    stat, p_norm = stats.shapiro(res)
    print(f"残差正态性检验 (Shapiro): p = {p_norm:.4f} {'(通过)' if p_norm > 0.05 else '(未通过)'}")

# ==========================================
# 考场调参指南 (EXAM QUICK START)
# ==========================================
"""
1. 读取数据: 
   df = pd.read_excel("你的文件名.xlsx")

2. 运行函数: 
   complete_twoway_anova_flow(df, value_col='数值列', factor1='第一个因素', factor2='第二个因素')

3. 结果解读:
   - PR(>F) 对应三个 P 值：因素1主效应、因素2主效应、交互作用。
   - 重点看交互作用 (factor1:factor2)：
     * 如果显著 (p<0.05)，说明两因素之间有干扰，必须看“交互作用图”。
     * 如果图中的线交叉了，说明两因素之间存在强交互。
   - Step 6: 残差正态性 p > 0.05 说明模型拟合效果好。
"""
