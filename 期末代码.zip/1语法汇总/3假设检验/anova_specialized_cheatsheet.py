import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats
import statsmodels.api as sm
from statsmodels.formula.api import ols
from statsmodels.stats.multicomp import pairwise_tukeyhsd

# =================================================================
# 1. 单因素方差分析 (One-way ANOVA)
# 场景: 比较 3 组及以上独立样本的均值差异 (如：低/中/高剂量组的疗效)
# =================================================================

def run_oneway_anova(df, value_col, group_col):
    """
    执行单因素方差分析及前提检查
    """
    print(f"=== 单因素 ANOVA: {value_col} by {group_col} ===")
    
    # 1. 前提检查: 方差齐性 (Levene Test)
    groups = [group[value_col].values for name, group in df.groupby(group_col)]
    w, p_levene = stats.levene(*groups)
    print(f"方差齐性检验 (Levene): p = {p_levene:.4f}")
    
    # 2. 执行 ANOVA
    model_name = f'{value_col} ~ C({group_col})'
    model = ols(model_name, data=df).fit()
    anova_table = sm.stats.anova_lm(model, typ=2)
    print("\nANOVA 表格:")
    print(anova_table)
    
    p_anova = anova_table['PR(>F)'][0]
    
    # 3. 如果结果显著 (p < 0.05)，执行事后检验 (Tukey HSD)
    if p_anova < 0.05:
        print("\n[结果显著] 正在执行 Tukey HSD 事后两两比较...")
        tukey = pairwise_tukeyhsd(endog=df[value_col], groups=df[group_col], alpha=0.05)
        print(tukey)
        # 可视化事后检验
        tukey.plot_simultaneous()
        plt.show()
    else:
        print("\n[结果不显著] 各组间无统计学差异。")
        
    return model

# =================================================================
# 2. 双因素方差分析 (Two-way ANOVA)
# 场景: 同时考虑两个分类变量的影响 (如：药物种类 + 性别)
# =================================================================

def run_twoway_anova(df, value_col, factor1, factor2, interaction=True):
    """
    执行双因素方差分析
    interaction=True: 考虑两个因素的交互作用 (factor1 * factor2)
    """
    print(f"=== 双因素 ANOVA: {value_col} by {factor1} & {factor2} ===")
    
    if interaction:
        formula = f'{value_col} ~ C({factor1}) + C({factor2}) + C({factor1}):C({factor2})'
    else:
        formula = f'{value_col} ~ C({factor1}) + C({factor2})'
    
    model = ols(formula, data=df).fit()
    anova_table = sm.stats.anova_lm(model, typ=2)
    print("\nANOVA 表格 (双因素):")
    print(anova_table)
    
    # 交互作用可视化 (Interaction Plot)
    plt.figure(figsize=(8, 6))
    from statsmodels.graphics.factorplots import interaction_plot
    fig = interaction_plot(x=df[factor1], trace=df[factor2], response=df[value_col], 
                          colors=['red', 'blue'], markers=['D', '^'])
    plt.title("Interaction Plot")
    plt.show()
    
    return model

# =================================================================
# 3. 假设验证 (残差分析)
# 场景: ANOVA 要求模型残差符合正态分布
# =================================================================

def check_anova_assumptions(model):
    """
    检查 ANOVA 模型的残差是否符合正态分布
    """
    residuals = model.resid
    
    # 1. 绘图检查
    fig, ax = plt.subplots(1, 2, figsize=(12, 5))
    sns.histplot(residuals, kde=True, ax=ax[0])
    ax[0].set_title("Residuals Histogram")
    
    sm.qqplot(residuals, line='s', ax=ax[1])
    ax[1].set_title("Residuals QQ-Plot")
    plt.show()
    
    # 2. 统计检验 (Shapiro-Wilk)
    stat, p = stats.shapiro(residuals)
    print(f"残差正态性检验 (Shapiro-Wilk): p = {p:.4f} ({'符合正态' if p>0.05 else '不符合正态'})")
    return p > 0.05

# ==========================================
# 考场调参指南 (EXAM QUICK START)
# ==========================================
"""
1. 单因素分析 (One-way):
   - 调用: run_oneway_anova(df, value_col='数值列', group_col='分组列')
   - 考点: 关注 Levene 检验 p 值(方差齐性) 和 ANOVA 表格中的 PR(>F)。

2. 双因素分析 (Two-way):
   - 调用: run_twoway_anova(df, value_col='数值列', factor1='因素1', factor2='因素2')
   - 考点: 观察交互项是否显著，以及交互作用图线段是否交叉。

3. 假设检查:
   - 调用: check_anova_assumptions(model)
   - 考点: 观察 QQ 图是否在直线上，Shapiro 检验 p > 0.05 则通过。
"""
