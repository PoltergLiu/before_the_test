import pandas as pd
import statsmodels.api as sm
from statsmodels.formula.api import ols

# 1. Data
m_a = [120, 122, 125, 128, 130, 132, 135, 128, 130, 125]
m_b = [115, 118, 120, 122, 125, 128, 130, 125, 120, 118]
f_a = [110, 112, 115, 118, 120, 123, 125, 120, 118, 115]
f_b = [105, 108, 110, 112, 115, 118, 120, 115, 112, 110]

data = {
    'bp': m_a + m_b + f_a + f_b,
    'sex': ['M']*20 + ['F']*20,
    'trt': (['A']*10 + ['B']*10) * 2
}
df = pd.DataFrame(data)

# 2. ANOVA
model = ols('bp ~ C(sex) * C(trt)', data=df).fit()
table = sm.stats.anova_lm(model, typ=2)

print("ANOVA Table:")
print(table)

# 3. Interpretation
p_int = table.loc['C(sex):C(trt)', 'PR(>F)']
if p_int < 0.05:
    print(f"\nSignificant interaction found (p={p_int:.4f}).")
else:
    print(f"\nNo significant interaction found (p={p_int:.4f}).")
