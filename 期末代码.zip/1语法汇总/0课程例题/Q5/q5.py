import pandas as pd
import numpy as np
import statsmodels.api as sm

# 1. Generate Dummy Data (as no real file found)
np.random.seed(42)
n = 200
df = pd.DataFrame({
    'age': np.random.randint(30, 80, n),
    'anemia': np.random.randint(0, 2, n),
    'diabetes': np.random.randint(0, 2, n),
    'gender': np.random.randint(0, 2, n),
    'smoke': np.random.randint(0, 2, n)
})
# Create hypertension risk based on age and diabetes
logit_y = -5 + 0.08 * df['age'] + 1.2 * df['diabetes'] + np.random.normal(0, 1, n)
df['hypertension'] = (logit_y > 0).astype(int)

# 2. Fit Logistic Regression
x = df[['age', 'anemia', 'diabetes', 'gender', 'smoke']]
x = sm.add_constant(x)
y = df['hypertension']

m = sm.Logit(y, x).fit()

# 3. Result
print(m.summary())

# 4. Significant features
p = m.pvalues
sig = p[p < 0.05].index.tolist()
if 'const' in sig: sig.remove('const')
print(f"\nSignificantly associated features: {sig}")
