import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from scipy import stats

# 1. Data
c = [220, 190, 210, 205, 200, 215, 195, 180, 210, 200, 220, 225, 205, 210, 195, 185, 200, 215, 210, 195, 205, 210, 220, 225, 190, 195, 200, 205, 210, 200, 190, 185, 210, 220, 230, 215, 195, 210, 200, 225, 210, 205, 190, 215, 200, 210, 220, 225, 190, 200]
t = [165, 170, 177, 172, 178, 180, 174, 169, 176, 182, 173, 175, 168, 171, 179, 184, 165, 177, 171, 180, 176, 174, 178, 181, 185, 163, 172, 170, 175, 169, 168, 176, 182, 177, 175, 173, 179, 181, 165, 174, 170, 186, 185, 160, 178, 175, 172, 169, 182, 187]

df = pd.DataFrame({'val': c + t, 'grp': ['Control']*50 + ['Treatment']*50})

# 2. Plot
plt.figure(figsize=(8, 6))
ax = sns.violinplot(x='grp', y='val', data=df)
mc = np.median(c)
mt = np.median(t)
plt.text(0, mc, f'Med:{mc}', ha='center', va='bottom', color='red')
plt.text(1, mt, f'Med:{mt}', ha='center', va='bottom', color='red')
plt.title('Cholesterol Levels')
plt.savefig('violin.png')
plt.show()

# 3. Test
# Normality
_, p1 = stats.shapiro(c)
_, p2 = stats.shapiro(t)
print(f'Normality p: Control={p1:.4f}, Treatment={p2:.4f}')

# Variance homogeneity
_, pv = stats.levene(c, t)
print(f'Variance p: {pv:.4f}')

# T-test
res = stats.ttest_ind(c, t)
print(f'T-test result: statistic={res.statistic:.4f}, p-value={res.pvalue:.4e}')
