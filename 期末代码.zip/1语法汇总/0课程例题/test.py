import numpy as np
import pandas as pd
import seaborn as sns
from scipy import stats
'''
A researcher investigates the effects of a new drug on
cholesterol levels. Two groups (control and treatment) each consisted of 50 participants,
and the data are shown below. 1) Plot the violin plots to perform descriptive analysis
on the two groups, with the median for each group labeled on the graphs, and describe
whether or not there are any unusual data points in the two groups?(5 points) (2) Choose
an appropriate statistical test of significance to test whether the new drug has a lowering
effect on cholesterol levels and give a conclusion. (10 points) (a=0.05)

Control group: [220, 190, 210, 205, 200, 215, 195, 180, 210, 200, 220, 225, 205, 210,
195, 185, 200, 215, 210, 195, 205, 210, 220, 225, 190, 195, 200, 205, 210, 200, 190,
185, 210, 220, 230, 215, 195, 210, 200, 225, 210, 205, 190, 215, 200, 210, 220, 225,
190, 200]
Treatment group: [165, 170, 177, 172, 178, 180, 174, 169, 176, 182, 173, 175, 168,
171, 179, 184, 165, 177, 171, 180, 176, 174, 178, 181, 185, 163, 172, 170, 175, 169,
168, 176, 182, 177, 175, 173, 179, 181, 165, 174, 170, 186, 185, 160, 178, 175, 172,
169, 182, 187]

import matplotlib.pyplot as plt
# 数据准备
control = [220, 190, 210, 205, 200, 215, 195, 180, 210, 200, 220, 225, 205, 210,
           195, 185, 200, 215, 210, 195, 205, 210, 220, 225, 190, 195, 200, 205,
           210, 200, 190, 185, 210, 220, 230, 215, 195, 210, 200, 225, 210, 205,
           190, 215, 200, 210, 220, 225, 190, 200]
treatment = [165, 170, 177, 172, 178, 180, 174, 169, 176, 182, 173, 175, 168,
             171, 179, 184, 165, 177, 171, 180, 176, 174, 178, 181, 185, 163,
             172, 170, 175, 169, 168, 176, 182, 177, 175, 173, 179, 181, 165,
             174, 170, 186, 185, 160, 178, 175, 172, 169, 182, 187]

df = pd.DataFrame({
    'Cholesterol': control + treatment,
    'Group': ['Control'] * 50 + ['Treatment'] * 50
})

# 1) 绘制小提琴图并标注中位数
plt.figure(figsize=(6, 4))
ax = sns.violinplot(x='Group', y='Cholesterol', data=df, inner=None, palette='Set2')
sns.stripplot(x='Group', y='Cholesterol', data=df, color='black', size=3, jitter=True, ax=ax)

# 计算并标注中位数
med_control = np.median(control)
med_treatment = np.median(treatment)
ax.text(0, med_control + 5, f'中位数: {med_control}', ha='center', fontsize=10, color='blue')
ax.text(1, med_treatment + 5, f'中位数: {med_treatment}', ha='center', fontsize=10, color='blue')

plt.title('胆固醇水平的小提琴图')
plt.ylabel('胆固醇水平 (mg/dL)')
plt.xlabel('组别')
plt.tight_layout()
plt.show()

# 异常值检查（使用IQR规则）
def detect_outliers(data, group_name):
    q1, q3 = np.percentile(data, [25, 75])
    iqr = q3 - q1
    lower, upper = q1 - 1.5 * iqr, q3 + 1.5 * iqr
    outliers = [x for x in data if x < lower or x > upper]
    if outliers:
        print(f"{group_name} 组发现异常值: {outliers}")
    else:
        print(f"{group_name} 组未发现异常值")

detect_outliers(control, "Control")
detect_outliers(treatment, "Treatment")

# 2) 假设检验：使用独立样本t检验（正态性&方差齐性满足）
# 正态性检验
_, p_c = stats.shapiro(control)
_, p_t = stats.shapiro(treatment)
print(f"Control 组Shapiro-Wilk p值: {p_c:.3f}")
print(f"Treatment 组Shapiro-Wilk p值: {p_t:.3f}")

# 方差齐性检验
_, p_lev = stats.levene(control, treatment)
print(f"Levene检验p值: {p_lev:.3f}")

# 独立样本t检验（单尾，检验“降低”效果）
t_stat, p_two = stats.ttest_ind(control, treatment, equal_var=True)
p_one = p_two / 2 if t_stat > 0 else 1 - p_two / 2
print(f"独立样本t检验统计量: {t_stat:.3f}")
print(f"单尾p值: {p_one:.3f}")

alpha = 0.05
if p_one < alpha:
    print(f"在α={alpha}水平下，拒绝原假设，认为新药显著降低胆固醇水平。")
else:
    print(f"在α={alpha}水平下，不拒绝原假设，尚无充分证据表明新药降低胆固醇水平。")

'''