import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
from scipy import stats

# 1. Data (Classic GSS 1988 AIDS Table)
# G: Gender, H: Health, I: Information, freq: Count
d = pd.DataFrame({
    'G': ['M', 'M', 'M', 'M', 'F', 'F', 'F', 'F'],
    'H': ['S', 'S', 'O', 'O', 'S', 'S', 'O', 'O'],
    'I': ['S', 'O', 'S', 'O', 'S', 'O', 'S', 'O'],
    'f': [155, 15, 181, 81, 171, 11, 192, 75]
})

# 2. Fit Models using Poisson Log-linear regression
# Model 1: Complete Independence [G][H][I]
m1 = smf.glm('f ~ G + H + I', data=d, family=sm.families.Poisson()).fit()

# Model 2: Joint Independence [G][HI]
m2 = smf.glm('f ~ G + H * I', data=d, family=sm.families.Poisson()).fit()

# Model 3: Conditional Independence [GI][GH]
m3 = smf.glm('f ~ G * I + G * H', data=d, family=sm.families.Poisson()).fit()

# 3. Evaluation
def eval_m(m, name):
    exp = m.predict()
    chi2 = np.sum((d['f'] - exp)**2 / exp)
    df = len(d) - len(m.params)
    p = 1 - stats.chi2.cdf(chi2, df)
    print(f"{name}: Chi2={chi2:.2f}, df={df}, p={p:.4f}")
    print("Expected values:", np.round(exp, 1))

eval_m(m1, "Complete Independence")
eval_m(m2, "Joint Independence")
eval_m(m3, "Conditional Independence")
