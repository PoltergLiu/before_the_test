import numpy as np
from scipy import stats

# 1. Data
a = [23, 30, 25, 21, 26, 27, 22, 24, 28, 29, 23, 31, 26, 25, 24, 22, 30, 27, 21, 26, 25, 28, 20, 29, 31, 24, 27, 30, 22, 25, 23, 26, 26, 25, 28, 24, 21, 30, 32, 20]
b = [30, 32, 33, 34, 35, 36, 37, 36, 38, 39, 34, 35, 40, 36, 33, 35, 38, 37, 34, 35, 36, 39, 33, 32, 31, 36, 35, 38, 37, 39, 40, 34, 33, 35, 36]

# 2. Check normality
_, pa = stats.shapiro(a)
_, pb = stats.shapiro(b)
print(f'Normality p: A={pa:.4f}, B={pb:.4f}')

# 3. Choose test
if pa > 0.05 and pb > 0.05:
    res = stats.ttest_ind(a, b)
    method = "Independent T-test"
else:
    res = stats.mannwhitneyu(a, b)
    method = "Mann-Whitney U test"

print(f'Method: {method}')
print(f'Statistic: {res.statistic:.4f}, P-value: {res.pvalue:.4e}')

# 4. Recommendation
if res.pvalue < 0.05:
    best = "A" if np.mean(a) < np.mean(b) else "B"
    print(f'Significant difference found. Recommend Treatment {best} (shorter stay).')
else:
    print('No significant difference found.')
