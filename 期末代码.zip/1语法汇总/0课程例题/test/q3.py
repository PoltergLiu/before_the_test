'''
Question 3. (20 points) Please analyze the impact of gender and treatment type on
blood pressure levels using the following dataset. Additionally, determine whether there
is an interaction effect between gender and treatment type on blood pressure levels.
Male Treatment A: 120, 122, 125, 128, 130, 132, 135, 128, 130, 125
Male Treatment B: 115, 118, 120, 122, 125, 128, 130, 125, 120, 118
Female Treatment A: 110, 112, 115, 118, 120, 123, 125, 120, 118, 115
Female Treatment B: 105, 108, 110, 112, 115, 118, 120, 115, 112, 110
'''
# 用文字分析上面的题目：

# 1. 采用双因素方差分析，将性别和治疗策略设置为两个因素， blood pressure levels 为响应变量。
# 2. 先进行数据清洗，代码：
import numpy as np
male_treatment_a = np.array([120, 122, 125, 128, 130, 132, 135, 128, 130, 125])
male_treatment_b = np.array([115, 118, 120, 122, 125, 128, 130, 125, 120, 118])
female_treatment_a = np.array([110, 112, 115, 118, 120, 123, 125, 120, 118, 115])
female_treatment_b = np.array([105, 108, 110, 112, 115, 118, 120, 115, 112, 110])
# 3. 进行双因素方差分析，代码：
from scipy.stats import f_oneway
f_stat, p_val = f_oneway(male_treatment_a, male_treatment_b, female_treatment_a, female_treatment_b)
print(f_stat, p_val)
# 4. 观察到结果p-value=1.6E-7，小于0.05，拒绝原假设，性别和治疗策略对blood pressure levels有显著影响。
# 5. 进行交互作用分析，代码：
from scipy.stats import f_oneway
f_stat, p_val = f_oneway(male_treatment_a, male_treatment_b, female_treatment_a, female_treatment_b)
print(f_stat, p_val)
# 6. 观察到结果p-value=1.6E-7，小于0.05，拒绝原假设，性别和治疗策略对blood pressure levels有显著交互影响。



'''
参考：
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats
import statsmodels.api as sm
from statsmodels.formula.api import ols
from statsmodels.stats.multicomp import pairwise_tukeyhsd
from statsmodels.graphics.factorplots import interaction_plot

# =================================================================
# 双因素方差分析 (Two-way ANOVA) 完整实战流程
# =================================================================

def complete_twoway_anova_flow(df, value_col, factor1, factor2):
    """
    输入:
    - df: DataFrame
    - value_col: 数值列 (如 'Effect')
    - factor1: 第一个分类变量 (如 'Drug')
    - factor2: 第二个分类变量 (如 'Gender')
    """
    print(f"{'='*20} 1. 分层描述性统计 {'='*20}")
    desc = df.groupby([factor1, factor2])[value_col].agg(['count', 'mean', 'std']).reset_index()
    print(desc)
    print("\n")

    print(f"{'='*20} 2. 构建模型与 ANOVA 计算 {'='*20}")
    # 建立线性模型，包含交互项 (factor1*factor2)
    # C() 表示强制设为分类变量
    formula = f'{value_col} ~ C({factor1}) + C({factor2}) + C({factor1}):C({factor2})'
    model = ols(formula, data=df).fit()
    
    # 执行 ANOVA (使用 Type II SS，更适合生物医学实验)
    anova_table = sm.stats.anova_lm(model, typ=2)
    print(anova_table)
    print("\n")

    # 提取 P 值
    p_f1 = anova_table.loc[f'C({factor1})', 'PR(>F)']
    p_f2 = anova_table.loc[f'C({factor2})', 'PR(>F)']
    p_inter = anova_table.loc[f'C({factor1}):C({factor2})', 'PR(>F)']

    print(f"{'='*20} 3. 结果解读 {'='*20}")
    print(f"- {factor1} 主效应: {'显著 (p<0.05)' if p_f1 < 0.05 else '不显著'}")
    print(f"- {factor2} 主效应: {'显著 (p<0.05)' if p_f2 < 0.05 else '不显著'}")
    print(f"- 交互作用 ({factor1}*{factor2}): {'显著 (p<0.05)' if p_inter < 0.05 else '不显著'}")
    print("\n")

    print(f"{'='*20} 4. 可视化 (交互作用图) {'='*20}")
    # 交互作用图是双因素 ANOVA 的灵魂
    plt.figure(figsize=(10, 6))
    fig = interaction_plot(x=df[factor1], trace=df[factor2], response=df[value_col],
                          colors=['red', 'blue', 'green'], markers=['D', '^', 'o'],
                          ms=10, ax=plt.gca())
    plt.title(f"Interaction Plot: {factor1} & {factor2}")
    plt.show()

    # 5. 事后检验 (如果交互作用显著)
    if p_inter < 0.05:
        print(f"{'='*20} 5. 事后检验 (Tukey HSD) {'='*20}")
        print("注意: 交互作用显著时，通常需要分析 '组合条件' 下的差异。")
        # 创建一个组合列用于事后比较
        df['combined'] = df[factor1].astype(str) + "_" + df[factor2].astype(str)
        tukey = pairwise_tukeyhsd(endog=df[value_col], groups=df['combined'], alpha=0.05)
        print(tukey.summary())
    
    # 6. 前提检查 (残差正态性)
    print(f"\n{'='*20} 6. 模型前提检查 {'='*20}")
    res = model.resid
    stat, p_norm = stats.shapiro(res)
    print(f"残差正态性检验 (Shapiro): p = {p_norm:.4f} {'(通过)' if p_norm > 0.05 else '(未通过)'}")

# =================================================================
# 考试快速调用示例
# =================================================================
if __name__ == "__main__":
    # 1. 构造模拟数据 (2种药物 A/B，在男女中的降压效果)
    data = pd.DataFrame({
        'drug': ['A']*20 + ['B']*20,
        'gender': (['Male']*10 + ['Female']*10) * 2,
        'reduction': np.concatenate([
            np.random.normal(15, 3, 10), # Drug A, Male
            np.random.normal(25, 3, 10), # Drug A, Female
            np.random.normal(12, 3, 10), # Drug B, Male
            np.random.normal(14, 3, 10)  # Drug B, Female
        ])
    })

    # 2. 调用流程
    complete_twoway_anova_flow(data, 'reduction', 'drug', 'gender')

'''