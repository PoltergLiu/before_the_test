'''
Question 2. (15 points) A hospital records the lengths of stay (in days) for patients
undergoing two different treatments for heart disease (data provided below). What
statistical test would you use to determine if there is a significant difference in length
of stay between the two treatment groups? Based on your analysis, which treatment
would you recommend as the better option? (a=0.05).
Group A: [23, 30, 25, 21, 26, 27, 22, 24, 28, 29, 23, 31, 26, 25, 24, 22, 30, 27, 21, 26,
25, 28, 20, 29, 31, 24, 27, 30, 22, 25, 23, 26, 26, 25, 28, 24, 21, 30, 32, 20;]
Group B: [30, 32, 33, 34, 35, 36, 37, 36, 38, 39, 34, 35, 40, 36, 33, 35, 38, 37, 34, 35,
36, 39, 33, 32, 31, 36, 35, 38, 37, 39, 40, 34, 33, 35, 36;]
'''

'''
# 1. 先进行假设检验：h0:miu_a = miu_b; 和 h1:miu_a ≠ miu_b
# 2. 先进行方差齐性检验
# 观察到结果p-value=，0.05，接受原假设，方差齐性
# 3. 进行t检验
# 观察到结果p-value=1.5e-12，小于0.05，拒绝原假设，group_a的length of stay均值小于group_b
'''
import numpy as np
from scipy.stats import levene
from scipy.stats import ttest_ind


# 清理数据，代码如下：
group_a = np.array([23, 30, 25, 21, 26, 27, 22, 24, 28, 29, 23, 31, 26, 25, 24, 22, 30, 27, 21, 26,
25, 28, 20, 29, 31, 24, 27, 30, 22, 25, 23, 26, 26, 25, 28, 24, 21, 30, 32, 20])
group_b = np.array([30, 32, 33, 34, 35, 36, 37, 36, 38, 39, 34, 35, 40, 36, 33, 35, 38, 37, 34, 35,
36, 39, 33, 32, 31, 36, 35, 38, 37, 39, 40, 34, 33, 35, 36])

# 1. 先进行假设检验：h0:miu_a = miu_b; 和 h1:miu_a ≠ miu_b，代码：
from scipy.stats import ttest_ind
ttest = ttest_ind(group_a, group_b, equal_var=True)
print(ttest)

# 2. 先进行方差齐性检验，代码：
from scipy.stats import levene
levene_test = levene(group_a, group_b)
print(levene_test)

# 3. 方差检验p=0.08>0.05，接受原假设，方差齐性；进行t检验（方差相等）：
ttest = ttest_ind(group_a, group_b, equal_var=True)
print(ttest)
# 4. 观察到结果p-value=6e-23，小于0.05，拒绝原假设，group_a的length of stay均值小于group_b
# 5. 因此，根据t检验结果，我们可以拒绝原假设，即group_a的length of stay均值小于group_b的length of stay均值。
# 6. 因此，我们建议使用group_b的治疗方法。