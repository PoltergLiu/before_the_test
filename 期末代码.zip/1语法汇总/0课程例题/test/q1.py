'''
Question 1. (15 points) A researcher investigates the effects of a new drug on
cholesterol levels. Two groups (control and treatment) each consisted of 50 participants,
and the data are shown below. 1) Plot the violin plots to perform descriptive analysis
on the two groups, with the median for each group labeled on the graphs, and describe
whether or not there are any unusual data points in the two groups?(5 points) (2) Choose
an appropriate statistical test of significance to test whether the new drug has a lowering
effect on cholesterol levels and give a conclusion. (10 points) (a=0.05)
Control group: [220, 190, 210, 205, 200, 215, 195, 180, 210, 200, 220, 225, 205, 210,
195, 185, 200, 215, 210, 195, 205, 210, 220, 225, 190, 195, 200, 205, 210, 200, 190,
185, 210, 220, 230, 215, 195, 210, 200, 225, 210, 205, 190, 215, 200, 210, 220, 225,
190, 200]
Treatment group: [165, 170, 177, 172, 178, 180, 174, 169, 176, 182, 173, 175, 168,
171, 179, 184, 165, 177, 171, 180, 176, 174, 178, 181, 185, 163, 172, 170, 175, 169,
168, 176, 182, 177, 175, 173, 179, 181, 165, 174, 170, 186, 185, 160, 178, 175, 172,
169, 182, 187]
'''

# Import the necessary libraries
import matplotlib.pyplot as plt
import numpy as np
from scipy.stats import norm

# Create the data
control = [220, 190, 210, 205, 200, 215, 195, 180, 210, 200, 220, 225, 205, 210,
195, 185, 200, 215, 210, 195, 205, 210, 220, 225, 190, 195, 200, 205, 210, 200, 190,
185, 210, 220, 230, 215, 195, 210, 200, 225, 210, 205, 190, 215, 200, 210, 220, 225,
190, 200]
treatment = [165, 170, 177, 172, 178, 180, 174, 169, 176, 182, 173, 175, 168, 171,
179, 184, 165, 177, 171, 180, 176, 174, 178, 181, 185, 163, 172, 170, 175, 169,
168, 176, 182, 177, 175, 173, 179, 181, 165, 174, 170, 186, 185, 160, 178, 175, 172,]

# Plot the violin plots
plt.violinplot([control, treatment], showmedians=True)
plt.xticks([1, 2], ['Control', 'Treatment'])
plt.ylabel('Cholesterol Level')
plt.title('Violin Plot of Cholesterol Levels in Control and Treatment Groups')
plt.show()

# 2. 先进行假设检验：h0:miu_treatment = miu_control; 和 h1:miu_treatment < miu_control
# 3. 先进行方差齐性检验
from scipy.stats import levene
levene_test = levene(control, treatment)
print(levene_test)
# 观察到结果p-value=9e-6，小于0.05，拒绝原假设，方差不齐
# 4.进行方差不匹配时的t检验
from scipy.stats import ttest_ind
ttest = ttest_ind(control, treatment, equal_var=False)
print(ttest)
# 观察到结果p-value=8e-26，小于0.05，拒绝原假设，treatment组的cholesterol level均值小于control组的cholesterol level均值
# 5. 因此，根据t检验结果，我们可以拒绝原假设，即treatment组的cholesterol level均值小于control组的cholesterol level均值。
# 6. 因此，我们建议使用treatment组的治疗方法。
