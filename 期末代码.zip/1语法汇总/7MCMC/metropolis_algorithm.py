# -*- coding: utf-8 -*-
"""
生物医学统计 - Metropolis 算法 (对称建议分布)
原理：
  1. 提出一个新状态 x_star ~ q(x_star | x_current)，其中 q 是对称的，如 Normal(x_current, sigma)。
  2. 计算接受率 alpha = min(1, p(x_star) / p(x_current))。
  3. 以概率 alpha 接受新状态。
"""

import numpy as np
import matplotlib.pyplot as plt
import scipy.stats as stats

# 设置中文显示
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False

def target_pdf(x):
    """
    目标分布 (通常是未归一化的后验分布)
    这里以两个正态分布的混合为例 (双峰分布)
    """
    return 0.3 * stats.norm.pdf(x, loc=-2, scale=1) + 0.7 * stats.norm.pdf(x, loc=3, scale=1.5)

def metropolis_sampler(target_func, n_iter, init_val, sigma):
    """
    Metropolis 采样器
    :param target_func: 目标分布函数
    :param n_iter: 迭代次数
    :param init_val: 初始值
    :param sigma: 建议分布的步长 (Normal(current, sigma))
    """
    samples = np.zeros(n_iter)
    samples[0] = init_val
    current_x = init_val
    n_accept = 0
    
    for i in range(1, n_iter):
        # 1. 提出新状态 (对称建议分布：正态分布)
        proposed_x = np.random.normal(current_x, sigma)
        
        # 2. 计算接受概率
        # alpha = p(proposed) / p(current)
        p_accept = target_func(proposed_x) / target_func(current_x)
        
        # 3. 接受/拒绝
        if np.random.rand() < p_accept:
            current_x = proposed_x
            n_accept += 1
        
        samples[i] = current_x
        
    print(f"Metropolis 采样完成。接受率: {n_accept/n_iter:.2%}")
    return samples

def plot_mcmc_results(samples, target_func):
    """可视化采样结果"""
    fig, ax = plt.subplots(1, 2, figsize=(15, 5))
    
    # Trace plot (轨迹图)
    ax[0].plot(samples, alpha=0.5)
    ax[0].set_title('Trace Plot (采样轨迹)')
    ax[0].set_xlabel('迭代次数')
    ax[0].set_ylabel('采样值')
    
    # Histogram vs Target PDF
    x = np.linspace(min(samples)-1, max(samples)+1, 500)
    ax[1].hist(samples, bins=50, density=True, alpha=0.6, label='采样直方图', color='skyblue')
    ax[1].plot(x, target_func(x), 'r-', lw=2, label='目标概率密度 (PDF)')
    ax[1].set_title('采样分布 vs 目标分布')
    ax[1].legend()
    
    plt.tight_layout()
    plt.show()

# ==========================================
# 考试调用指南
# ==========================================
if __name__ == "__main__":
    # 参数设置
    ITER = 10000     # 采样次数
    START = 0.0      # 起始点
    STEP_SIZE = 1.0  # 建议分布步长 (步长过大接受率低，过小收敛慢)
    
    # 运行采样
    m_samples = metropolis_sampler(target_pdf, ITER, START, STEP_SIZE)
    
    # 丢弃前 10% 的 Burn-in 期
    burn_in = int(ITER * 0.1)
    final_samples = m_samples[burn_in:]
    
    # 可视化
    plot_mcmc_results(final_samples, target_pdf)
    
    print(f"采样均值: {np.mean(final_samples):.4f}")
    print(f"采样标准差: {np.std(final_samples):.4f}")
