# -*- coding: utf-8 -*-
"""
生物医学统计 - Metropolis-Hastings (M-H) 算法
原理：
  1. 提出新状态 x_star ~ q(x_star | x_current)，q 可以是非对称的。
  2. 计算接受率 alpha = min(1, [p(x_star) * q(x_current | x_star)] / [p(x_current) * q(x_star | x_current)])。
  3. M-H 算法修正了建议分布不对称导致的偏差。
"""

import numpy as np
import matplotlib.pyplot as plt
import scipy.stats as stats

# 设置中文显示
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False

def target_posterior(x):
    """目标分布：这里假设是一个 Gamma 分布 (只能在 x > 0 采样)"""
    if x <= 0: return 0
    return stats.gamma.pdf(x, a=2.5, scale=2.0)

def mh_sampler(target_func, n_iter, init_val):
    """
    Metropolis-Hastings 采样器
    建议分布使用非对称的：Lognormal(ln(current), 0.5)
    """
    samples = np.zeros(n_iter)
    samples[0] = init_val
    current_x = init_val
    n_accept = 0
    
    for i in range(1, n_iter):
        # 1. 提出新状态：从对数正态分布采样 (确保 x > 0)
        # q(x_star | x_curr)
        sigma_q = 0.5
        proposed_x = np.random.lognormal(mean=np.log(current_x), sigma=sigma_q)
        
        # 2. 计算 M-H 修正项 (Correction factor)
        # q(curr | star) / q(star | curr)
        # 对于 Lognormal，q(x|mu,s) = (1/xs) * exp(-(lnx-mu)^2/2s^2)
        q_star_given_curr = stats.lognormal.pdf(proposed_x, s=sigma_q, scale=current_x)
        q_curr_given_star = stats.lognormal.pdf(current_x, s=sigma_q, scale=proposed_x)
        
        # 3. 计算接受概率 alpha
        # alpha = [p(star) / p(curr)] * [q(curr|star) / q(star|curr)]
        ratio = (target_func(proposed_x) / target_func(current_x)) * (q_curr_given_star / q_star_given_curr)
        
        # 4. 接受/拒绝
        if np.random.rand() < ratio:
            current_x = proposed_x
            n_accept += 1
            
        samples[i] = current_x
        
    print(f"M-H 采样完成。接受率: {n_accept/n_iter:.2%}")
    return samples

def plot_mh_results(samples, target_func):
    """可视化采样结果"""
    fig, ax = plt.subplots(1, 2, figsize=(15, 5))
    
    # Trace plot
    ax[0].plot(samples, color='green', alpha=0.5)
    ax[0].set_title('M-H Trace Plot (采样轨迹)')
    
    # Histogram vs Target PDF
    x = np.linspace(0.1, max(samples)+1, 500)
    ax[1].hist(samples, bins=50, density=True, alpha=0.6, label='M-H 采样直方图', color='lightgreen')
    ax[1].plot(x, [target_func(xi) for xi in x], 'r-', lw=2, label='目标 Gamma 分布')
    ax[1].set_title('M-H 采样分布 vs 目标分布')
    ax[1].legend()
    
    plt.tight_layout()
    plt.show()

# ==========================================
# 考试调用指南
# ==========================================
if __name__ == "__main__":
    # 参数设置
    ITER = 10000
    START = 1.0  # 必须大于 0，因为目标分布是 Gamma
    
    # 运行采样
    mh_samples = mh_sampler(target_posterior, ITER, START)
    
    # 丢弃 Burn-in
    burn_in = int(ITER * 0.1)
    final_samples = mh_samples[burn_in:]
    
    # 可视化
    plot_mh_results(final_samples, target_posterior)
    
    print(f"采样均值: {np.mean(final_samples):.4f} (理论值: {2.5*2.0})")
    print(f"采样标准差: {np.std(final_samples):.4f} (理论值: {np.sqrt(2.5)*2.0:.4f})")
